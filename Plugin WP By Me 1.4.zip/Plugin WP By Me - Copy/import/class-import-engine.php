<?php
namespace SEOMetaImporterPro\Import;

defined('ABSPATH') || exit;

class Import_Engine {
    private string $file_path;
    private array $mapping;
    private array $settings;
    private int $import_id = 0;
    private array $backed_up_objects = []; // Tracks which objects/keys have been backed up in this run

    public function __construct(string $file_path, array $mapping, array $settings) {
        $this->file_path = $file_path;
        $this->mapping = $mapping;
        $this->settings = wp_parse_args($settings, [
            'identifier_type' => 'auto', // auto, url, slug, id
            'seo_plugin'      => 'auto',
            'dry_run'         => false,
            'filters'         => [], // post types / taxonomies to limit to
        ]);
    }

    public function set_import_id(int $import_id): void {
        $this->import_id = $import_id;
    }

    /**
     * Run validation and return pre-import analysis.
     */
    public function analyze_import(int $limit = 50): array {
        if (!file_exists($this->file_path)) {
            return ['error' => __('CSV file not found.', 'seo-meta-importer-pro')];
        }

        $total_rows = Csv_Parser::get_total_rows($this->file_path);
        $headers = Csv_Parser::get_headers($this->file_path);
        
        // Find identifier column
        $identifier_col = $this->get_identifier_column($headers);

        // Read rows for analysis
        $rows = Csv_Parser::parse_rows($this->file_path, 0, $total_rows);

        $stats = [
            'total_rows' => $total_rows,
            'matched'    => 0,
            'not_found'  => 0,
            'duplicates' => 0,
            'invalid'    => 0,
            'warnings'   => 0,
        ];

        $seen_identifiers = [];
        $analysis_rows = [];
        $warnings_list = [];

        $bridge = \SEOMetaImporterPro\SEO\SEO_Bridge::get_bridge_instance($this->settings['seo_plugin']);

        foreach ($rows as $index => $row) {
            $identifier_val = $row[$identifier_col] ?? '';
            $is_duplicate = false;
            $is_invalid = false;
            $object_info = null;

            if (empty($identifier_val)) {
                $is_invalid = true;
                $stats['invalid']++;
                $warnings_list[] = sprintf(__('Row %d: Missing page identifier.', 'seo-meta-importer-pro'), $index + 2);
            } else {
                // Check duplicate
                $normalized_id = strtolower(trim($identifier_val));
                if (isset($seen_identifiers[$normalized_id])) {
                    $is_duplicate = true;
                    $stats['duplicates']++;
                    $warnings_list[] = sprintf(__('Row %d: Duplicate identifier "%s" (already seen in row %d).', 'seo-meta-importer-pro'), $index + 2, $identifier_val, $seen_identifiers[$normalized_id] + 2);
                } else {
                    $seen_identifiers[$normalized_id] = $index;
                }

                // URL format check if it looks like a URL
                if (strpos($identifier_val, 'http') === 0 && !filter_var($identifier_val, FILTER_VALIDATE_URL)) {
                    $is_invalid = true;
                    $stats['invalid']++;
                    $warnings_list[] = sprintf(__('Row %d: Invalid URL format "%s".', 'seo-meta-importer-pro'), $index + 2, $identifier_val);
                }
            }

            if (!$is_invalid) {
                // Resolve WordPress object
                $object_info = \SEOMetaImporterPro\Includes\Helper::resolve_identifier(
                    $identifier_val,
                    $this->settings['filters']['post_types'] ?? [],
                    $this->settings['filters']['taxonomies'] ?? []
                );

                if ($object_info) {
                    $stats['matched']++;
                } else {
                    $stats['not_found']++;
                    $warnings_list[] = sprintf(__('Row %d: No matching WordPress post, page, or term found for "%s".', 'seo-meta-importer-pro'), $index + 2, $identifier_val);
                }
            }

            // Perform metadata validation if matched
            if ($object_info) {
                // Check description length
                foreach ($this->mapping as $csv_col => $field_key) {
                    if ($field_key === 'description' && !empty($row[$csv_col])) {
                        if (mb_strlen($row[$csv_col]) > 160) {
                            $stats['warnings']++;
                            $warnings_list[] = sprintf(__('Row %d: Meta description is %d characters (recommended is under 160).', 'seo-meta-importer-pro'), $index + 2, mb_strlen($row[$csv_col]));
                        }
                    }
                    if ($field_key === 'title' && empty($row[$csv_col])) {
                        $stats['warnings']++;
                        $warnings_list[] = sprintf(__('Row %d: Mapped SEO Title column is empty.', 'seo-meta-importer-pro'), $index + 2);
                    }
                }
            }

            // Only push a sample to the preview screen to save memory
            if ($index < $limit) {
                $preview_fields = [];
                if ($object_info) {
                    foreach ($this->mapping as $csv_col => $field_key) {
                        if ($field_key === '_identifier') {
                            continue;
                        }
                        
                        $new_val = $row[$csv_col] ?? '';
                        $old_val = '';
                        if (strpos($field_key, 'custom:') === 0) {
                            $custom_bridge = new \SEOMetaImporterPro\SEO\Custom_Bridge();
                            $old_val = $custom_bridge->get_meta($object_info['id'], $object_info['type'], $field_key);
                        } else {
                            $old_val = $bridge->get_meta($object_info['id'], $object_info['type'], $field_key);
                        }

                        $preview_fields[] = [
                            'field' => $field_key,
                            'old'   => $old_val,
                            'new'   => $new_val,
                        ];
                    }
                }

                $analysis_rows[] = [
                    'row_num'     => $index + 2,
                    'identifier'  => $identifier_val,
                    'status'      => $object_info ? 'matched' : ($is_invalid ? 'invalid' : 'not_found'),
                    'object_type' => $object_info ? $object_info['type'] : '',
                    'sub_type'    => $object_info ? $object_info['sub_type'] : '',
                    'object_id'   => $object_info ? $object_info['id'] : 0,
                    'wp_title'    => $object_info ? ($object_info['type'] === 'post' ? get_the_title($object_info['id']) : get_term($object_info['id'])->name) : '',
                    'fields'      => $preview_fields,
                    'is_duplicate'=> $is_duplicate,
                ];
            }
        }

        return [
            'stats'         => $stats,
            'warnings'      => $warnings_list,
            'preview_rows'  => $analysis_rows,
            'headers'       => $headers,
            'detected_identifier' => $identifier_col,
        ];
    }

    /**
     * Process a batch of rows.
     */
    public function process_batch(int $offset, int $limit): array|\WP_Error {
        if (!file_exists($this->file_path)) {
            return new \WP_Error('file_not_found', __('CSV file not found.', 'seo-meta-importer-pro'));
        }

        $headers = Csv_Parser::get_headers($this->file_path);
        $identifier_col = $this->get_identifier_column($headers);

        $rows = Csv_Parser::parse_rows($this->file_path, $offset, $limit);
        if (empty($rows)) {
            return ['updated' => 0, 'failed' => 0];
        }

        $updated_count = 0;
        $failed_count = 0;

        $bridge = \SEOMetaImporterPro\SEO\SEO_Bridge::get_bridge_instance($this->settings['seo_plugin']);

        foreach ($rows as $index => $row) {
            $identifier_val = $row[$identifier_col] ?? '';
            if (empty($identifier_val)) {
                $failed_count++;
                continue;
            }

            // Resolve object
            $object_info = \SEOMetaImporterPro\Includes\Helper::resolve_identifier(
                $identifier_val,
                $this->settings['filters']['post_types'] ?? [],
                $this->settings['filters']['taxonomies'] ?? []
            );

            if (!$object_info) {
                $failed_count++;
                continue;
            }

            $object_id = $object_info['id'];
            $object_type = $object_info['type'];

            // Perform update
            $row_success = false;

            if ($this->settings['dry_run']) {
                // In dry run, we just simulate success
                $row_success = true;
            } else {
                // Real Import: Update meta values
                $updated_fields = 0;
                
                foreach ($this->mapping as $csv_col => $field_key) {
                    if ($field_key === '_identifier' || !isset($row[$csv_col])) {
                        continue;
                    }

                    $new_value = $row[$csv_col];

                    // Back up old value for rollback before writing
                    $this->backup_field_meta($object_id, $object_type, $field_key, $bridge);

                    // Update
                    if (strpos($field_key, 'custom:') === 0) {
                        $custom_bridge = new \SEOMetaImporterPro\SEO\Custom_Bridge();
                        $result = $custom_bridge->update_meta($object_id, $object_type, $field_key, $new_value);
                    } else {
                        $result = $bridge->update_meta($object_id, $object_type, $field_key, $new_value);
                    }

                    if ($result) {
                        $updated_fields++;
                    }
                }

                if ($updated_fields > 0) {
                    $row_success = true;
                }
            }

            // Trigger developer hooks
            if ($row_success) {
                $updated_count++;
                do_action('smip_import_row_success', $object_id, $object_type, $row, $this->settings);
            } else {
                $failed_count++;
                do_action('smip_import_row_failed', $identifier_val, $row, $this->settings);
            }
        }

        return [
            'updated' => $updated_count,
            'failed'  => $failed_count,
        ];
    }

    /**
     * Backup metadata to the database before modifying it.
     */
    private function backup_field_meta(int $object_id, string $object_type, string $field_key, \SEOMetaImporterPro\SEO\SEO_Bridge $bridge): void {
        if ($this->import_id === 0) {
            return;
        }

        // Determine actual meta key(s) impacted by this field key
        // Serialized plugins like Slim SEO or TSF write to a single key, Yoast/RankMath write to separate keys
        $meta_keys = [];
        $bridge_name = $bridge->get_name();

        if (strpos($field_key, 'custom:') === 0) {
            $meta_keys[] = substr($field_key, 7);
        } elseif ($bridge_name === 'slimseo') {
            $meta_keys[] = 'slim_seo';
        } elseif ($bridge_name === 'tsf') {
            $meta_keys[] = 'autodescription-custom';
        } else {
            // For Yoast, RankMath, AIOSEO, SEOPress, the class-specific bridges use internal maps
            // Let's resolve the specific meta key
            $ref_prop = new \ReflectionProperty($bridge, 'field_map');
            $ref_prop->setAccessible(true);
            $field_map = $ref_prop->getValue($bridge);
            
            $meta_key = $field_map[$field_key] ?? '';
            if (!empty($meta_key)) {
                $meta_keys[] = $meta_key;
                
                // Yoast term meta fallback checks stripped keys too
                if ($bridge_name === 'yoast' && $object_type === 'term') {
                    $meta_keys[] = ltrim($meta_key, '_');
                }
            }
        }

        foreach ($meta_keys as $meta_key) {
            $cache_key = "{$object_type}_{$object_id}_{$meta_key}";
            if (isset($this->backed_up_objects[$cache_key])) {
                continue; // Already backed up original value in this import run
            }

            // Retrieve current DB value
            $current_val = '';
            if ($object_type === 'term') {
                $current_val = get_term_meta($object_id, $meta_key, true);
            } else {
                $current_val = get_post_meta($object_id, $meta_key, true);
            }

            // Serialize array/objects for SQL storage
            $stored_val = is_scalar($current_val) ? (string)$current_val : serialize($current_val);

            \SEOMetaImporterPro\Includes\Database::insert_rollback(
                $this->import_id,
                $object_id,
                $object_type,
                $meta_key,
                $stored_val
            );

            $this->backed_up_objects[$cache_key] = true;
        }
    }

    /**
     * Determine which column holds the URL/ID/Slug.
     */
    private function get_identifier_column(array $headers): string {
        // 1. Look for mapped _identifier
        foreach ($this->mapping as $csv_col => $field_key) {
            if ($field_key === '_identifier') {
                return $csv_col;
            }
        }

        // 2. Look for common headers
        $common_identifiers = ['url', 'permalink', 'link', 'id', 'post_id', 'slug', 'post_slug'];
        foreach ($headers as $header) {
            if (in_array(strtolower(trim($header)), $common_identifiers, true)) {
                return $header;
            }
        }

        // 3. Fallback to first column
        return !empty($headers) ? $headers[0] : '';
    }
}
