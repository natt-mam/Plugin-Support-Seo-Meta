<?php
namespace SEOMetaImporterPro\Import;

defined('ABSPATH') || exit;

class Csv_Parser {
    /**
     * Get total row count (excluding header if requested).
     */
    public static function get_total_rows(string $file_path): int {
        if (!file_exists($file_path) || !is_readable($file_path)) {
            return 0;
        }

        $handle = fopen($file_path, 'r');
        if (!$handle) {
            return 0;
        }

        $count = 0;
        // Efficient line counting that doesn't load file in memory
        while (!feof($handle)) {
            $line = fgets($handle);
            if ($line !== false && trim($line) !== '') {
                $count++;
            }
        }
        fclose($handle);

        // Subtract 1 for header row (if greater than 0)
        return $count > 0 ? $count - 1 : 0;
    }

    /**
     * Extract headers from the CSV.
     */
    public static function get_headers(string $file_path, string $delimiter = ',', string $encoding = 'UTF-8'): array {
        if (!file_exists($file_path) || !is_readable($file_path)) {
            return [];
        }

        $handle = fopen($file_path, 'r');
        if (!$handle) {
            return [];
        }

        // Read first row
        $headers = fgetcsv($handle, 0, $delimiter);
        fclose($handle);

        if (!is_array($headers)) {
            return [];
        }

        // Clean headers and convert encoding if needed
        return array_map(function($header) use ($encoding) {
            $header = self::convert_encoding(trim($header), 'UTF-8', $encoding);
            // Strip BOM if present
            $bom = pack('H*', 'EFBBBF');
            if (preg_match("/^$bom/", $header)) {
                $header = substr($header, 3);
            }
            return trim($header);
        }, $headers);
    }

    /**
     * Parse a batch of rows.
     * 
     * @param int $offset 0-based offset of data rows (0 is first data row, which is the 2nd line of the file)
     */
    public static function parse_rows(string $file_path, int $offset, int $limit, string $delimiter = ',', string $encoding = 'UTF-8'): array {
        if (!file_exists($file_path) || !is_readable($file_path)) {
            return [];
        }

        $handle = fopen($file_path, 'r');
        if (!$handle) {
            return [];
        }

        $headers = fgetcsv($handle, 0, $delimiter);
        if (!is_array($headers)) {
            fclose($handle);
            return [];
        }

        // Strip BOM and clean headers
        $headers = array_map(function($header) use ($encoding) {
            $header = self::convert_encoding(trim($header), 'UTF-8', $encoding);
            $bom = pack('H*', 'EFBBBF');
            if (preg_match("/^$bom/", $header)) {
                $header = substr($header, 3);
            }
            return trim($header);
        }, $headers);

        // Skip rows until we reach the offset
        $skipped = 0;
        while ($skipped < $offset && !feof($handle)) {
            $row = fgetcsv($handle, 0, $delimiter);
            if ($row !== false) {
                $skipped++;
            }
        }

        // Read up to limit rows
        $rows = [];
        $read = 0;
        while ($read < $limit && !feof($handle)) {
            $row = fgetcsv($handle, 0, $delimiter);
            if ($row === false) {
                break;
            }

            // Skip empty rows
            if (empty($row) || (count($row) === 1 && $row[0] === null)) {
                continue;
            }

            // Map row to headers
            $mapped_row = [];
            foreach ($headers as $index => $header) {
                $val = isset($row[$index]) ? trim($row[$index]) : '';
                $val = self::convert_encoding($val, 'UTF-8', $encoding);
                $mapped_row[$header] = $val;
            }

            $rows[] = $mapped_row;
            $read++;
        }

        fclose($handle);
        return $rows;
    }

    /**
     * Helper to convert encoding.
     */
    private static function convert_encoding(string $string, string $to_encoding, string $from_encoding): string {
        if (empty($string)) {
            return '';
        }
        if (empty($from_encoding)) {
            $from_encoding = mb_detect_encoding($string, mb_detect_order(), true) ?: 'UTF-8';
        }
        if (strcasecmp($to_encoding, $from_encoding) === 0) {
            return $string;
        }
        // Suppress warnings in case of invalid characters
        return @mb_convert_encoding($string, $to_encoding, $from_encoding);
    }
}
