<?php
namespace SEOMetaImporterPro\Logger;

defined('ABSPATH') || exit;

class Logger {
    private string $log_dir;
    private string $log_file;

    public function __construct() {
        $upload_dir = wp_upload_dir();
        $this->log_dir = $upload_dir['basedir'] . '/smip-logs';
        $this->log_file = $this->log_dir . '/debug.log';
    }

    /**
     * Write message to the log file.
     */
    public function log(string $message, string $level = 'info'): void {
        // Only log if debug mode is enabled, or if it's an error/warning
        $debug_mode = get_option('smip_debug_mode', 'no');
        if ($debug_mode !== 'yes' && $level === 'debug') {
            return;
        }

        if (!file_exists($this->log_dir)) {
            wp_mkdir_p($this->log_dir);
            file_put_contents($this->log_dir . '/index.html', '');
            file_put_contents($this->log_dir . '/.htaccess', 'Deny from all');
        }

        $timestamp = current_time('mysql');
        $formatted = sprintf("[%s] [%s] %s\n", $timestamp, strtoupper($level), $message);

        // Append log, ensuring it doesn't exceed 10MB
        if (file_exists($this->log_file) && filesize($this->log_file) > 10 * 1024 * 1024) {
            rename($this->log_file, $this->log_file . '.bak');
        }

        error_log($formatted, 3, $this->log_file);
    }

    /**
     * Read the last N lines of the log file.
     */
    public function get_recent_entries(int $lines = 100): string {
        if (!file_exists($this->log_file) || !is_readable($this->log_file)) {
            return __('No logs available.', 'seo-meta-importer-pro');
        }

        $file = fopen($this->log_file, 'r');
        if (!$file) {
            return __('Failed to read log file.', 'seo-meta-importer-pro');
        }

        $buffer = [];
        while (!feof($file)) {
            $line = fgets($file);
            if ($line !== false && trim($line) !== '') {
                $buffer[] = trim($line);
            }
        }
        fclose($file);

        // Slice to get last N lines
        $total = count($buffer);
        $start = max(0, $total - $lines);
        $recent = array_slice($buffer, $start, $lines);

        return implode("\n", $recent);
    }

    /**
     * Clear all log contents.
     */
    public function clear_logs(): bool {
        if (file_exists($this->log_file)) {
            return unlink($this->log_file);
        }
        return true;
    }

    /**
     * Export history table to CSV for downloading.
     * 
     * @return string|null File path of the CSV, or null on failure.
     */
    public static function generate_history_csv(): ?string {
        $history = \SEOMetaImporterPro\Includes\Database::get_history(1000, 0); // Limit to last 1000 runs
        if (empty($history)) {
            return null;
        }

        $upload_dir = wp_upload_dir();
        $temp_dir = $upload_dir['basedir'] . '/smip-temp';
        if (!file_exists($temp_dir)) {
            wp_mkdir_p($temp_dir);
        }

        $file_path = $temp_dir . '/history-export-' . time() . '.csv';
        $fp = fopen($file_path, 'w');
        if (!$fp) {
            return null;
        }

        // Write BOM for Excel
        fwrite($fp, chr(0xEF) . chr(0xBB) . chr(0xBF));

        // Headers
        fputcsv($fp, [
            'ID',
            'Date',
            'User',
            'File/Source',
            'Rows Updated',
            'Rows Failed',
            'SEO Plugin Used',
            'Execution Time (s)',
            'Status',
            'Import Type',
        ]);

        foreach ($history as $row) {
            $user = get_userdata($row['user_id']);
            $username = $user ? $user->user_login : __('Unknown User', 'seo-meta-importer-pro');

            fputcsv($fp, [
                $row['id'],
                $row['date'],
                $username,
                $row['filename'],
                $row['rows_updated'],
                $row['rows_failed'],
                $row['seo_plugin'],
                $row['execution_time'],
                $row['status'],
                $row['import_type'],
            ]);
        }

        fclose($fp);
        return $file_path;
    }
}
