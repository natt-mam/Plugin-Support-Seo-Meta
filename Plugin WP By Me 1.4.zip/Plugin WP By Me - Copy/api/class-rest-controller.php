<?php
namespace SEOMetaImporterPro\API;

defined('ABSPATH') || exit;

class Rest_Controller extends \WP_REST_Controller {
    protected string $namespace = 'seo-meta-importer-pro/v1';

    /**
     * Register REST routes.
     */
    public function register_routes(): void {
        register_rest_route($this->namespace, '/history', [
            [
                'methods'             => \WP_REST_Server::READABLE,
                'callback'            => [$this, 'get_history'],
                'permission_callback' => [$this, 'check_permission'],
            ]
        ]);

        register_rest_route($this->namespace, '/status', [
            [
                'methods'             => \WP_REST_Server::READABLE,
                'callback'            => [$this, 'get_status'],
                'permission_callback' => [$this, 'check_permission'],
            ]
        ]);

        register_rest_route($this->namespace, '/sync', [
            [
                'methods'             => \WP_REST_Server::CREATABLE,
                'callback'            => [$this, 'trigger_sync'],
                'permission_callback' => [$this, 'check_permission'],
            ]
        ]);

        register_rest_route($this->namespace, '/import', [
            [
                'methods'             => \WP_REST_Server::CREATABLE,
                'callback'            => [$this, 'run_import'],
                'permission_callback' => [$this, 'check_permission'],
                'args'                => [
                    'file_path' => [
                        'required'          => true,
                        'type'              => 'string',
                        'sanitize_callback' => 'sanitize_text_field',
                    ],
                    'mapping' => [
                        'required'          => true,
                        'type'              => 'object',
                    ],
                ]
            ]
        ]);
    }

    /**
     * Permission Callback.
     */
    public function check_permission(): bool {
        return current_user_can('manage_options');
    }

    /**
     * Get Import History.
     */
    public function get_history(\WP_REST_Request $request): \WP_REST_Response {
        $limit = intval($request->get_param('limit') ?: 20);
        $offset = intval($request->get_param('offset') ?: 0);

        $history = \SEOMetaImporterPro\Includes\Database::get_history($limit, $offset);
        return new \WP_REST_Response($history, 200);
    }

    /**
     * Get Current/Last Import Status.
     */
    public function get_status(\WP_REST_Request $request): \WP_REST_Response {
        $history = \SEOMetaImporterPro\Includes\Database::get_history(1, 0);
        if (empty($history)) {
            return new \WP_REST_Response(['message' => __('No imports recorded.', 'seo-meta-importer-pro')], 200);
        }
        return new \WP_REST_Response($history[0], 200);
    }

    /**
     * Trigger Google Sheets Sync.
     */
    public function trigger_sync(\WP_REST_Request $request): \WP_REST_Response {
        $url = get_option('smip_google_sheet_url', '');
        if (empty($url)) {
            return new \WP_REST_Response(['message' => __('Google Sheet URL is not configured.', 'seo-meta-importer-pro')], 400);
        }

        // Trigger sync asynchronously using background hook or directly
        // Because REST requests should return quickly, we can schedule a single background event
        wp_schedule_single_event(time(), 'smip_google_sheets_sync_cron');

        return new \WP_REST_Response([
            'message' => __('Google Sheets sync task has been scheduled and will run in the background.', 'seo-meta-importer-pro')
        ], 202);
    }

    /**
     * Run metadata import directly from a file.
     */
    public function run_import(\WP_REST_Request $request): \WP_REST_Response {
        $file_path = $request->get_param('file_path');
        $mapping_raw = $request->get_param('mapping');

        if (!file_exists($file_path)) {
            return new \WP_REST_Response(['message' => __('Specified CSV file not found on server.', 'seo-meta-importer-pro')], 400);
        }

        $mapping = [];
        foreach ($mapping_raw as $k => $v) {
            $mapping[sanitize_text_field($k)] = sanitize_text_field($v);
        }

        $settings = [
            'seo_plugin' => sanitize_text_field($request->get_param('seo_plugin') ?: 'auto'),
            'dry_run'    => (bool) $request->get_param('dry_run'),
            'filters'    => [
                'post_types' => (array) $request->get_param('post_types'),
                'taxonomies' => (array) $request->get_param('taxonomies'),
            ],
        ];

        // Insert history record
        $import_id = \SEOMetaImporterPro\Includes\Database::insert_history([
            'filename'    => basename($file_path),
            'seo_plugin'  => $settings['seo_plugin'],
            'status'      => 'running',
            'import_type' => 'api_request',
        ]);

        if ($import_id === 0) {
            return new \WP_REST_Response(['message' => __('Failed to insert history record.', 'seo-meta-importer-pro')], 500);
        }

        $engine = new \SEOMetaImporterPro\Import\Import_Engine($file_path, $mapping, $settings);
        $engine->set_import_id($import_id);

        $total_rows = \SEOMetaImporterPro\Import\Csv_Parser::get_total_rows($file_path);
        
        $start_time = microtime(true);
        $updated = 0;
        $failed = 0;
        $offset = 0;
        $batch = 500;

        while ($offset < $total_rows) {
            $result = $engine->process_batch($offset, $batch);
            if (is_wp_error($result)) {
                $failed += $total_rows - $offset;
                break;
            }
            $updated += $result['updated'];
            $failed += $result['failed'];
            $offset += $batch;
        }

        $end_time = microtime(true);
        $execution_time = $end_time - $start_time;

        \SEOMetaImporterPro\Includes\Database::update_history($import_id, [
            'rows_updated'   => $updated,
            'rows_failed'    => $failed,
            'execution_time' => $execution_time,
            'status'         => 'completed',
        ]);

        return new \WP_REST_Response([
            'import_id'      => $import_id,
            'rows_updated'   => $updated,
            'rows_failed'    => $failed,
            'execution_time' => $execution_time,
            'status'         => 'completed',
        ], 200);
    }
}
