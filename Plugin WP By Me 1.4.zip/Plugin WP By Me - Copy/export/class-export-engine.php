<?php
namespace SEOMetaImporterPro\Export;

defined('ABSPATH') || exit;

class Export_Engine {
    /**
     * Generate the SEO metadata export file.
     * 
     * @return string|array File path of the generated CSV, or WP_Error.
     */
    public static function generate_export(array $filters, string $seo_plugin = 'auto'): string|\WP_Error {
        $post_types = $filters['post_types'] ?? [];
        $taxonomies = $filters['taxonomies'] ?? [];

        if (empty($post_types) && empty($taxonomies)) {
            return new \WP_Error('no_filters', __('Select at least one post type or taxonomy to export.', 'seo-meta-importer-pro'));
        }

        // Get upload dir for temp storage
        $upload_dir = wp_upload_dir();
        $export_dir = $upload_dir['basedir'] . '/smip-exports';
        if (!file_exists($export_dir)) {
            wp_mkdir_p($export_dir);
            file_put_contents($export_dir . '/index.html', '');
            file_put_contents($export_dir . '/.htaccess', 'Deny from all');
        }

        $filename = 'seo-export-' . date('Y-m-d-His') . '-' . wp_generate_password(6, false) . '.csv';
        $file_path = $export_dir . '/' . $filename;

        $fp = fopen($file_path, 'w');
        if (!$fp) {
            return new \WP_Error('write_error', __('Failed to open export file for writing.', 'seo-meta-importer-pro'));
        }

        // Write UTF-8 BOM for Excel compatibility
        fwrite($fp, chr(0xEF) . chr(0xBB) . chr(0xBF));

        // CSV Headers
        $headers = [
            'URL',
            'Type',
            'Sub Type',
            'WordPress Title',
            'SEO Title',
            'Meta Description',
            'Focus Keyword',
            'Canonical URL',
            'Robots Index',
            'Robots Follow',
            'OG Title',
            'OG Description',
            'Twitter Title',
            'Twitter Description',
        ];
        fputcsv($fp, $headers);

        $bridge = \SEOMetaImporterPro\SEO\SEO_Bridge::get_bridge_instance($seo_plugin);

        // 1. Export Posts
        if (!empty($post_types)) {
            $paged = 1;
            $posts_per_page = 500;
            
            while (true) {
                $query = new \WP_Query([
                    'post_type'      => $post_types,
                    'post_status'    => 'any',
                    'posts_per_page' => $posts_per_page,
                    'paged'          => $paged,
                    'fields'         => 'ids',
                    'no_found_rows'  => true,
                ]);

                if (empty($query->posts)) {
                    break;
                }

                foreach ($query->posts as $post_id) {
                    $post = get_post($post_id);
                    $url = get_permalink($post_id);

                    $row = [
                        $url,
                        'post',
                        $post->post_type,
                        $post->post_title,
                        $bridge->get_meta($post_id, 'post', 'title'),
                        $bridge->get_meta($post_id, 'post', 'description'),
                        $bridge->get_meta($post_id, 'post', 'focus_keyword'),
                        $bridge->get_meta($post_id, 'post', 'canonical'),
                        $bridge->get_meta($post_id, 'post', 'robots_index'),
                        $bridge->get_meta($post_id, 'post', 'robots_follow'),
                        $bridge->get_meta($post_id, 'post', 'og_title'),
                        $bridge->get_meta($post_id, 'post', 'og_description'),
                        $bridge->get_meta($post_id, 'post', 'twitter_title'),
                        $bridge->get_meta($post_id, 'post', 'twitter_description'),
                    ];
                    fputcsv($fp, $row);
                }

                $paged++;
                // Clean memory
                wp_cache_flush();
            }
        }

        // 2. Export Terms
        if (!empty($taxonomies)) {
            $number = 500;
            $offset = 0;

            while (true) {
                $terms = get_terms([
                    'taxonomy'   => $taxonomies,
                    'hide_empty' => false,
                    'number'     => $number,
                    'offset'     => $offset,
                ]);

                if (empty($terms) || is_wp_error($terms)) {
                    break;
                }

                foreach ($terms as $term) {
                    $url = get_term_link($term);
                    if (is_wp_error($url)) {
                        $url = '';
                    }

                    $row = [
                        $url,
                        'term',
                        $term->taxonomy,
                        $term->name,
                        $bridge->get_meta($term->term_id, 'term', 'title'),
                        $bridge->get_meta($term->term_id, 'term', 'description'),
                        $bridge->get_meta($term->term_id, 'term', 'focus_keyword'),
                        $bridge->get_meta($term->term_id, 'term', 'canonical'),
                        $bridge->get_meta($term->term_id, 'term', 'robots_index'),
                        $bridge->get_meta($term->term_id, 'term', 'robots_follow'),
                        $bridge->get_meta($term->term_id, 'term', 'og_title'),
                        $bridge->get_meta($term->term_id, 'term', 'og_description'),
                        $bridge->get_meta($term->term_id, 'term', 'twitter_title'),
                        $bridge->get_meta($term->term_id, 'term', 'twitter_description'),
                    ];
                    fputcsv($fp, $row);
                }

                $offset += $number;
                wp_cache_flush();
            }
        }

        fclose($fp);
        return $file_path;
    }
}
