<?php
namespace SEOMetaImporterPro\Google;

defined('ABSPATH') || exit;

class Sheets_Sync {
    /**
     * Register cron hooks.
     */
    public static function register_cron_actions(): void {
        add_filter('cron_schedules', [self::class, 'add_cron_schedules']);
        add_action('smip_google_sheets_sync_cron', [self::class, 'execute_sync']);
    }

    /**
     * Add custom weekly schedule.
     */
    public static function add_cron_schedules(array $schedules): array {
        if (!isset($schedules['weekly'])) {
            $schedules['weekly'] = [
                'interval' => 7 * DAY_IN_SECONDS,
                'display'  => __('Once Weekly', 'seo-meta-importer-pro'),
            ];
        }
        return $schedules;
    }

    /**
     * Schedule or reschedule the sync.
     */
    public static function reschedule(): void {
        wp_clear_scheduled_hook('smip_google_sheets_sync_cron');

        $sync_interval = get_option('smip_auto_sync', 'manual');
        if ($sync_interval === 'manual') {
            return;
        }

        if (!wp_next_scheduled('smip_google_sheets_sync_cron')) {
            wp_schedule_event(time() + 60, $sync_interval, 'smip_google_sheets_sync_cron');
        }
    }

    /**
     * Execute sync from background cron task.
     */
    public static function execute_sync(): void {
        $url = get_option('smip_google_sheet_url', '');
        if (empty($url)) {
            return;
        }

        $api_key = get_option('smip_google_sheets_api_key', '');
        
        // Log action start
        $logger = new \SEOMetaImporterPro\Logger\Logger();
        $logger->log('Starting scheduled Google Sheets sync.');

        $file_path = Sheets_Client::download_sheet_to_file($url, $api_key);
        if (is_wp_error($file_path)) {
            $logger->log('Scheduled Sync Failed: ' . $file_path->get_error_message(), 'error');
            return;
        }

        // Setup import parameters from saved mapping settings
        $mapping = get_option('smip_saved_mapping', []);
        $settings = [
            'identifier_type' => get_option('smip_saved_identifier_type', 'auto'),
            'seo_plugin'      => get_option('smip_default_seo_plugin', 'auto'),
            'dry_run'         => false,
            'filters'         => get_option('smip_saved_filters', []),
        ];

        if (empty($mapping)) {
            // No saved mapping, try to build default mapping where header == field key
            $headers = \SEOMetaImporterPro\Import\Csv_Parser::get_headers($file_path);
            if (!empty($headers)) {
                $mapping = [];
                // We'll map anything that matches common names
                $field_keys = [
                    'url'                 => ['url', 'permalink', 'link', 'page url', 'product url'],
                    'title'               => ['title', 'seo title', 'meta title'],
                    'description'         => ['description', 'meta description', 'meta desc'],
                    'focus_keyword'       => ['keyword', 'keywords', 'focus keyword', 'keyphrase'],
                    'canonical'           => ['canonical', 'canonical url'],
                    'robots_index'        => ['robots index', 'noindex', 'index'],
                    'robots_follow'       => ['robots follow', 'nofollow', 'follow'],
                    'og_title'            => ['og title', 'facebook title', 'open graph title'],
                    'og_description'      => ['og description', 'facebook description', 'open graph description'],
                    'twitter_title'       => ['twitter title'],
                    'twitter_description' => ['twitter description'],
                ];

                foreach ($headers as $header) {
                    $cleaned_header = strtolower(trim($header));
                    $mapped = false;

                    foreach ($field_keys as $key => $synonyms) {
                        if (in_array($cleaned_header, $synonyms, true)) {
                            $mapping[$header] = $key;
                            $mapped = true;
                            break;
                        }
                    }

                    if (!$mapped) {
                        // Check if it's a generic column we want to skip or treat as custom
                        // In auto sync, we skip if not matched, or keep as custom
                    }
                }
            }
        }

        if (empty($mapping)) {
            $logger->log('Scheduled Sync Failed: No valid column mapping configuration found.', 'error');
            unlink($file_path);
            return;
        }

        // Run full import in background
        $import_engine = new \SEOMetaImporterPro\Import\Import_Engine($file_path, $mapping, $settings);
        
        $start_time = microtime(true);
        $total_rows = \SEOMetaImporterPro\Import\Csv_Parser::get_total_rows($file_path);
        
        // Process in chunks in a single cron run since it runs in background
        $offset = 0;
        $batch_size = 500; // Larger batch for background CLI/Cron
        $updated = 0;
        $failed = 0;

        // Initialize history record
        $history_id = \SEOMetaImporterPro\Includes\Database::insert_history([
            'filename'    => basename($url),
            'seo_plugin'  => $settings['seo_plugin'],
            'status'      => 'running',
            'import_type' => 'google_sheets',
        ]);

        $import_engine->set_import_id($history_id);

        while ($offset < $total_rows) {
            $result = $import_engine->process_batch($offset, $batch_size);
            if (is_wp_error($result)) {
                $failed += $total_rows - $offset;
                break;
            }
            $updated += $result['updated'];
            $failed += $result['failed'];
            $offset += $batch_size;
        }

        $end_time = microtime(true);
        $execution_time = $end_time - $start_time;

        \SEOMetaImporterPro\Includes\Database::update_history($history_id, [
            'rows_updated'   => $updated,
            'rows_failed'    => $failed,
            'execution_time' => $execution_time,
            'status'         => 'completed',
        ]);

        $logger->log(sprintf('Scheduled Sync Completed. Updated: %d, Failed: %d. Execution time: %.2f seconds.', $updated, $failed, $execution_time));

        // Clean up temporary file
        unlink($file_path);
    }
}
