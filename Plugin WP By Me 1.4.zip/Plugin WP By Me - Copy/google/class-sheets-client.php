<?php
namespace SEOMetaImporterPro\Google;

defined('ABSPATH') || exit;

class Sheets_Client {
    /**
     * Parse Google Sheets URL to get the CSV export URL.
     */
    public static function get_csv_export_url(string $url): string {
        // Extract spreadsheet ID
        preg_match('/\/d\/([a-zA-Z0-9-_]+)/', $url, $matches);
        if (empty($matches[1])) {
            return '';
        }
        $spreadsheet_id = $matches[1];

        // Extract gid (sheet tab ID)
        $gid = '0';
        if (preg_match('/[#&?]gid=([0-9]+)/', $url, $gid_matches)) {
            $gid = $gid_matches[1];
        }

        return "https://docs.google.com/spreadsheets/d/{$spreadsheet_id}/export?format=csv&gid={$gid}";
    }

    /**
     * Download Google Sheet CSV to a local file.
     */
    public static function download_sheet_to_file(string $url, string $api_key = ''): string|array {
        if (!empty($api_key)) {
            return self::download_via_api($url, $api_key);
        }

        $csv_url = self::get_csv_export_url($url);
        if (empty($csv_url)) {
            return new \WP_Error('invalid_url', __('Invalid Google Sheets URL format.', 'seo-meta-importer-pro'));
        }

        // Fetch sheet
        $response = wp_remote_get($csv_url, [
            'timeout'   => 30,
            'sslverify' => false,
        ]);

        if (is_wp_error($response)) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code($response);
        if ($code !== 200) {
            return new \WP_Error('http_error', sprintf(__('HTTP Error %d: Unable to fetch Google Sheet. Make sure the sheet is public (anyone with the link can view).', 'seo-meta-importer-pro'), $code));
        }

        $body = wp_remote_retrieve_body($response);
        if (empty($body)) {
            return new \WP_Error('empty_response', __('Google Sheet returned no data.', 'seo-meta-importer-pro'));
        }

        // Write to temporary file
        $upload_dir = wp_upload_dir();
        $temp_dir = $upload_dir['basedir'] . '/smip-temp';
        if (!file_exists($temp_dir)) {
            wp_mkdir_p($temp_dir);
            // Protect directory
            file_put_contents($temp_dir . '/index.html', '');
            file_put_contents($temp_dir . '/.htaccess', 'Deny from all');
        }

        $temp_file = $temp_dir . '/sheet-' . uniqid() . '.csv';
        if (file_put_contents($temp_file, $body) === false) {
            return new \WP_Error('write_error', __('Failed to write temporary file.', 'seo-meta-importer-pro'));
        }

        return $temp_file;
    }

    /**
     * Download via Google Sheets API (Fallback/Alternative).
     */
    private static function download_via_api(string $url, string $api_key): string|array {
        preg_match('/\/d\/([a-zA-Z0-9-_]+)/', $url, $matches);
        if (empty($matches[1])) {
            return new \WP_Error('invalid_url', __('Invalid Google Sheets URL format.', 'seo-meta-importer-pro'));
        }
        $spreadsheet_id = $matches[1];

        // Call Sheets API v4
        // Get metadata first to get the sheet names
        $meta_url = "https://sheets.googleapis.com/v4/spreadsheets/{$spreadsheet_id}?key={$api_key}";
        $response = wp_remote_get($meta_url, ['timeout' => 30, 'sslverify' => false]);
        if (is_wp_error($response)) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code($response);
        if ($code !== 200) {
            return new \WP_Error('api_error', sprintf(__('Google Sheets API Error %d: Check API key and sheet access settings.', 'seo-meta-importer-pro'), $code));
        }

        $meta_data = json_decode(wp_remote_retrieve_body($response), true);
        $sheet_name = $meta_data['sheets'][0]['properties']['title'] ?? 'Sheet1';

        // Fetch values
        $encoded_sheet_name = rawurlencode($sheet_name);
        $values_url = "https://sheets.googleapis.com/v4/spreadsheets/{$spreadsheet_id}/values/{$encoded_sheet_name}?key={$api_key}";
        
        $response_values = wp_remote_get($values_url, ['timeout' => 30, 'sslverify' => false]);
        if (is_wp_error($response_values)) {
            return $response_values;
        }

        $values_data = json_decode(wp_remote_retrieve_body($response_values), true);
        $values = $values_data['values'] ?? [];

        if (empty($values)) {
            return new \WP_Error('empty_api_values', __('No data retrieved from API.', 'seo-meta-importer-pro'));
        }

        // Convert array to CSV string
        $output = fopen('php://temp', 'r+');
        foreach ($values as $row) {
            fputcsv($output, $row);
        }
        rewind($output);
        $csv_content = stream_get_contents($output);
        fclose($output);

        $upload_dir = wp_upload_dir();
        $temp_dir = $upload_dir['basedir'] . '/smip-temp';
        if (!file_exists($temp_dir)) {
            wp_mkdir_p($temp_dir);
            file_put_contents($temp_dir . '/index.html', '');
            file_put_contents($temp_dir . '/.htaccess', 'Deny from all');
        }

        $temp_file = $temp_dir . '/sheet-' . uniqid() . '.csv';
        if (file_put_contents($temp_file, $csv_content) === false) {
            return new \WP_Error('write_error', __('Failed to write temporary API file.', 'seo-meta-importer-pro'));
        }

        return $temp_file;
    }
}
