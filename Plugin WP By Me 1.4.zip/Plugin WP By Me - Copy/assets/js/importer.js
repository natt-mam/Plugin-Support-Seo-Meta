/**
 * SEO Meta Importer Pro - Import Engine Wizard Script
 */

jQuery(document).ready(function($) {
    'use strict';

    // State Variables
    var currentStep = 1;
    var uploadFile = null;
    var filePath = '';
    var csvHeaders = [];
    var totalRows = 0;
    var isPaused = false;
    var isCancelled = false;
    var importId = 0;
    var currentOffset = 0;
    var batchSize = 100;
    var totalUpdated = 0;
    var totalFailed = 0;
    var importStartTime = 0;
    
    // WordPress SEO destinations list
    var seoFields = {
        '': '— Skip Field —',
        '_identifier': 'Page Identifier (URL/Slug/ID)',
        'title': 'SEO Title',
        'description': 'Meta Description',
        'focus_keyword': 'Focus Keyword',
        'canonical': 'Canonical URL',
        'robots_index': 'Robots Index (index/noindex)',
        'robots_follow': 'Robots Follow (follow/nofollow)',
        'og_title': 'Open Graph Title',
        'og_description': 'Open Graph Description',
        'twitter_title': 'Twitter Title',
        'twitter_description': 'Twitter Description',
        'schema_type': 'Schema Type (if supported)',
        'custom': 'Custom Meta Key...'
    };

    // 1. Wizard Navigation functions
    function goToStep(step) {
        currentStep = step;
        
        // Update Step Headers
        $('.smip-step').removeClass('active');
        $('.smip-step[data-step="' + step + '"]').addClass('active');
        
        for (var i = 1; i < step; i++) {
            $('.smip-step[data-step="' + i + '"]').addClass('completed');
        }

        // Switch panes
        $('.smip-wizard-pane').removeClass('active');
        $('.smip-wizard-pane[data-pane="' + step + '"]').addClass('active');
    }

    // 2. Drag and Drop File Handlers
    var $dropzone = $('#smip-csv-dropzone');
    var $fileInput = $('#smip-csv-file-input');

    $dropzone.on('click', function() {
        $fileInput.click();
    });

    $dropzone.on('dragover', function(e) {
        e.preventDefault();
        $dropzone.addClass('dragover');
    });

    $dropzone.on('dragleave', function() {
        $dropzone.removeClass('dragover');
    });

    $dropzone.on('drop', function(e) {
        e.preventDefault();
        $dropzone.removeClass('dragover');
        
        var files = e.originalEvent.dataTransfer.files;
        if (files.length) {
            handleFileSelect(files[0]);
        }
    });

    $fileInput.on('change', function() {
        if (this.files.length) {
            handleFileSelect(this.files[0]);
        }
    });

    function handleFileSelect(file) {
        if (file.name.slice(-4).toLowerCase() !== '.csv') {
            alert('Please select a valid CSV file.');
            return;
        }
        uploadFile = file;
        $('#smip-filename-display').text(file.name + ' (' + formatBytes(file.size) + ')');
        $('#smip-upload-info').show();
        $('#smip-btn-to-step2').prop('disabled', false);
    }

    function formatBytes(bytes) {
        if (bytes === 0) return '0 Bytes';
        var k = 1024;
        var dm = 2;
        var sizes = ['Bytes', 'KB', 'MB', 'GB'];
        var i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
    }

    // 3. Handle Google Sheets Sync Redirection
    $(document).on('smip_google_sheet_fetched', function(e, data) {
        filePath = data.file_path;
        csvHeaders = data.headers;
        totalRows = data.total_rows;
        uploadFile = null; // Mark as Google Sheets

        // Auto transition to step 2 mapping
        setupMappingRows();
        goToStep(2);
    });

    // 4. File Upload (Transition from Step 1 to Step 2)
    $('#smip-btn-to-step2').on('click', function() {
        if (!uploadFile && filePath === '') {
            alert(SMIP.strings.select_file);
            return;
        }

        if (uploadFile) {
            var formData = new FormData();
            formData.append('action', 'smip_upload_csv');
            formData.append('security', SMIP.nonce);
            formData.append('file', uploadFile);
            formData.append('delimiter', $('#smip-csv-delimiter').val());
            formData.append('encoding', $('#smip-csv-encoding').val());

            var $btn = $(this);
            $btn.prop('disabled', true).text('Uploading...');

            $.ajax({
                url: SMIP.ajax_url,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                        filePath = response.data.file_path;
                        csvHeaders = response.data.headers;
                        totalRows = response.data.total_rows;
                        
                        setupMappingRows();
                        goToStep(2);
                    } else {
                        alert(response.data.message || 'File upload failed.');
                    }
                    $btn.prop('disabled', false).html('Next: Map Columns &rarr;');
                },
                error: function() {
                    alert('Server error while uploading.');
                    $btn.prop('disabled', false).html('Next: Map Columns &rarr;');
                }
            });
        } else {
            // Already have Google Sheets path
            setupMappingRows();
            goToStep(2);
        }
    });

    // Build mapping rows dynamically
    function setupMappingRows() {
        var $tbody = $('#smip-mapping-rows');
        $tbody.empty();

        csvHeaders.forEach(function(header, idx) {
            var $tr = $('<tr>');
            var $tdSource = $('<td>').html('<strong>' + escapeHtml(header) + '</strong>');
            var $tdArrow = $('<td>').text('→');
            var $tdDest = $('<td>');

            var $select = $('<select>').attr('name', 'mapping[' + header + ']').addClass('smip-field-selector');
            
            // Build options
            $.each(seoFields, function(key, label) {
                $select.append($('<option>').val(key).text(label));
            });

            // Automatically pre-map based on matches
            var cleanedHeader = header.toLowerCase().trim();
            if (cleanedHeader === 'url' || cleanedHeader === 'permalink' || cleanedHeader === 'link' || idx === 0) {
                $select.val('_identifier');
            } else if (cleanedHeader.indexOf('title') !== -1) {
                $select.val('title');
            } else if (cleanedHeader.indexOf('desc') !== -1) {
                $select.val('description');
            } else if (cleanedHeader.indexOf('keyword') !== -1 || cleanedHeader.indexOf('keyphrase') !== -1) {
                $select.val('focus_keyword');
            } else if (cleanedHeader.indexOf('canonical') !== -1) {
                $select.val('canonical');
            } else if (cleanedHeader.indexOf('robots index') !== -1 || cleanedHeader === 'noindex') {
                $select.val('robots_index');
            } else if (cleanedHeader.indexOf('robots follow') !== -1 || cleanedHeader === 'nofollow') {
                $select.val('robots_follow');
            } else if (cleanedHeader.indexOf('og title') !== -1 || cleanedHeader.indexOf('facebook title') !== -1) {
                $select.val('og_title');
            } else if (cleanedHeader.indexOf('og desc') !== -1 || cleanedHeader.indexOf('facebook desc') !== -1) {
                $select.val('og_description');
            } else if (cleanedHeader.indexOf('twitter title') !== -1) {
                $select.val('twitter_title');
            } else if (cleanedHeader.indexOf('twitter desc') !== -1) {
                $select.val('twitter_description');
            } else {
                $select.val('');
            }

            // Create custom meta text input (hidden by default)
            var $customInput = $('<input>')
                .attr('type', 'text')
                .addClass('smip-custom-field-input regular-text')
                .attr('placeholder', 'Enter custom meta key name')
                .css('display', 'none')
                .attr('name', 'custom_mapping[' + header + ']');

            $select.on('change', function() {
                if ($(this).val() === 'custom') {
                    $customInput.show().prop('required', true);
                } else {
                    $customInput.hide().prop('required', false).val('');
                }
            });

            $tdDest.append($select).append($customInput);
            $tr.append($tdSource).append($tdArrow).append($tdDest);
            $tbody.append($tr);

            // Trigger change if preset value is custom (not applicable here, but good practice)
            $select.trigger('change');
        });
    }

    // 5. Mapping Step Navigation Back/Next
    $('#smip-btn-back-to-step1').on('click', function() {
        goToStep(1);
    });

    $('#smip-btn-to-step3').on('click', function() {
        // Verify we mapped an identifier and at least one other field
        var mappings = getMappingData();
        var hasIdentifier = false;
        var hasField = false;

        $.each(mappings, function(csvCol, fieldKey) {
            if (fieldKey === '_identifier') {
                hasIdentifier = true;
            } else if (fieldKey !== '') {
                hasField = true;
            }
        });

        if (!hasIdentifier) {
            alert('Please map at least one CSV column as your Page Identifier (URL/Slug/ID) to resolve pages correctly.');
            return;
        }

        if (!hasField) {
            alert(SMIP.strings.no_mapping);
            return;
        }

        goToStep(3);
    });

    // 6. Config Filters Navigation Back/Next (Validating CSV)
    $('.smip-wizard-pane[data-pane="3"] #smip-btn-back-to-step2').on('click', function() {
        goToStep(2);
    });

    $('#smip-btn-to-step4').on('click', function() {
        var mapping = getMappingData();
        var postTypes = [];
        $('input[name="smip-import-post-types"]:checked').each(function() {
            postTypes.push($(this).val());
        });

        var taxonomies = [];
        $('input[name="smip-import-taxonomies"]:checked').each(function() {
            taxonomies.push($(this).val());
        });

        var $btn = $(this);
        $btn.prop('disabled', true).text(SMIP.strings.analyzing);

        $.ajax({
            url: SMIP.ajax_url,
            type: 'POST',
            data: {
                action: 'smip_analyze_preview',
                security: SMIP.nonce,
                file_path: filePath,
                mapping: mapping,
                post_types: postTypes,
                taxonomies: taxonomies,
                seo_plugin: $('#smip-import-seo-plugin').val()
            },
            success: function(response) {
                if (response.success) {
                    var data = response.data;
                    
                    // Populate Stats
                    $('#smip-stat-total').text(data.stats.total_rows);
                    $('#smip-stat-matched').text(data.stats.matched);
                    $('#smip-stat-notfound').text(data.stats.not_found);
                    $('#smip-stat-duplicates').text(data.stats.duplicates);

                    // Render Warnings
                    var $warningsContainer = $('#smip-warnings-container');
                    var $warningsList = $('#smip-warnings-list');
                    $warningsList.empty();

                    if (data.warnings && data.warnings.length) {
                        data.warnings.forEach(function(warn) {
                            $warningsList.append($('<div>').text(warn));
                        });
                        $warningsContainer.show();
                    } else {
                        $warningsContainer.hide();
                    }

                    // Render Sample Rows Preview Table
                    var $tbody = $('#smip-preview-rows');
                    $tbody.empty();

                    if (data.preview_rows && data.preview_rows.length) {
                        data.preview_rows.forEach(function(pRow) {
                            var $tr = $('<tr>');
                            
                            $tr.append($('<td>').text(pRow.row_num));
                            $tr.append($('<td>').html('<code class="smip-code-path">' + escapeHtml(pRow.identifier) + '</code>'));
                            
                            var statusClass = 'smip-status-' + pRow.status;
                            var statusLbl = pRow.status === 'matched' ? 'Found' : (pRow.status === 'invalid' ? 'Invalid URL' : 'Not Found');
                            $tr.append($('<td>').html('<span class="smip-status-badge-inline ' + statusClass + '">' + statusLbl + '</span>'));
                            
                            $tr.append($('<td>').html(pRow.status === 'matched' ? '<strong>' + escapeHtml(pRow.wp_title) + '</strong> <span class="smip-type-tag">' + pRow.sub_type + '</span>' : '<span class="smip-text-muted">—</span>'));
                            
                            // Fields diff table
                            var $diffTd = $('<td>');
                            if (pRow.status === 'matched' && pRow.fields && pRow.fields.length) {
                                var $diffTable = $('<table class="smip-preview-diff-subtable" style="width:100%; border:none;">');
                                pRow.fields.forEach(function(f) {
                                    var $diffTr = $('<tr>');
                                    $diffTr.append($('<td style="border:none; width:30%; padding:2px;">').html('<strong>' + f.field + '</strong>'));
                                    $diffTr.append($('<td style="border:none; width:35%; padding:2px; text-decoration:line-through; color:#94a3b8;">').text(f.old || '[empty]'));
                                    $diffTr.append($('<td style="border:none; width:35%; padding:2px; color:#10b981;">').text(f.new || '[empty]'));
                                    $diffTable.append($diffTr);
                                });
                                $diffTd.append($diffTable);
                            } else {
                                $diffTd.text('—');
                            }
                            $tr.append($diffTd);
                            $tbody.append($tr);
                        });
                    } else {
                        $tbody.append('<tr><td colspan="5">No preview data available.</td></tr>');
                    }

                    goToStep(4);
                } else {
                    alert(response.data.message || 'Validation failed.');
                }
                $btn.prop('disabled', false).html('Validate & Preview &rarr;');
            },
            error: function() {
                alert('Server error during validation.');
                $btn.prop('disabled', false).html('Validate & Preview &rarr;');
            }
        });
    });

    // 7. Preview Navigation Back/Confirm (Start Bulk Import)
    $('.smip-wizard-pane[data-pane="4"] #smip-btn-back-to-step3').on('click', function() {
        goToStep(3);
    });

    $('#smip-btn-confirm-import').on('click', function() {
        // Reset state
        isPaused = false;
        isCancelled = false;
        currentOffset = 0;
        totalUpdated = 0;
        totalFailed = 0;
        importStartTime = Date.now();

        $('#smip-import-console-logs').text('');
        writeToConsole('Initializing bulk import run...');

        // Start import (inserts record in DB history)
        var filename = uploadFile ? uploadFile.name : 'Google Sheet';
        var seoPlugin = $('#smip-import-seo-plugin').val();
        var importType = uploadFile ? 'csv' : 'google_sheets';

        $.ajax({
            url: SMIP.ajax_url,
            type: 'POST',
            data: {
                action: 'smip_start_import',
                security: SMIP.nonce,
                filename: filename,
                seo_plugin: seoPlugin,
                import_type: importType
            },
            success: function(response) {
                if (response.success) {
                    importId = response.data.import_id;
                    writeToConsole('Import history initialized with ID: #' + importId);
                    
                    // Read custom batch size from general settings if defined, else fallback to 100
                    // For safety, we start batches
                    goToStep(5);
                    executeBatch();
                } else {
                    alert(response.data.message || 'Failed to start import.');
                }
            },
            error: function() {
                alert('Server error occurred while starting import.');
            }
        });
    });

    // 8. Recursive Batch Executor
    function executeBatch() {
        if (isPaused) {
            writeToConsole('Import PAUSED by admin.');
            return;
        }

        if (isCancelled) {
            writeToConsole('Import CANCELLED. halting execution.');
            cancelImportOnBackend();
            return;
        }

        writeToConsole('Processing rows ' + (currentOffset + 1) + ' to ' + (currentOffset + batchSize) + ' of ' + totalRows + '...');

        var mapping = getMappingData();
        var postTypes = [];
        $('input[name="smip-import-post-types"]:checked').each(function() {
            postTypes.push($(this).val());
        });

        var taxonomies = [];
        $('input[name="smip-import-taxonomies"]:checked').each(function() {
            taxonomies.push($(this).val());
        });

        var dryRun = $('#smip-import-dry-run').is(':checked');

        $.ajax({
            url: SMIP.ajax_url,
            type: 'POST',
            data: {
                action: 'smip_import_batch',
                security: SMIP.nonce,
                file_path: filePath,
                import_id: importId,
                offset: currentOffset,
                limit: batchSize,
                mapping: mapping,
                post_types: postTypes,
                taxonomies: taxonomies,
                seo_plugin: $('#smip-import-seo-plugin').val(),
                dry_run: dryRun
            },
            success: function(response) {
                if (response.success) {
                    var data = response.data;
                    totalUpdated += data.updated;
                    totalFailed += data.failed;

                    writeToConsole('Batch success: ' + data.updated + ' updated, ' + data.failed + ' failed.');

                    currentOffset += batchSize;
                    
                    // Update progress UI
                    var pct = Math.min(100, Math.round((currentOffset / totalRows) * 100));
                    $('#smip-import-progress-fill').css('width', pct + '%');
                    $('#smip-progress-percent').text(pct + '%');
                    $('#smip-progress-fraction').text(Math.min(currentOffset, totalRows) + ' / ' + totalRows + ' processed');

                    if (currentOffset < totalRows) {
                        // Recursively call next batch
                        executeBatch();
                    } else {
                        // Import fully completed
                        writeToConsole('Import successfully finished!');
                        writeToConsole('Total metadata fields updated: ' + totalUpdated);
                        writeToConsole('Total rows skipped/failed: ' + totalFailed);
                        
                        completeImportOnBackend('completed');
                    }
                } else {
                    writeToConsole('Batch error: ' + (response.data.message || 'Unknown server error.'), 'error');
                    completeImportOnBackend('failed');
                }
            },
            error: function() {
                writeToConsole('Connection error: server failed to respond. Retrying batch...', 'warning');
                // Auto-retry once or twice in production, here we fail after warning
                completeImportOnBackend('failed');
            }
        });
    }

    // Backend Complete
    function completeImportOnBackend(finalStatus) {
        $.ajax({
            url: SMIP.ajax_url,
            type: 'POST',
            data: {
                action: 'smip_complete_import',
                security: SMIP.nonce,
                import_id: importId,
                file_path: filePath,
                rows_updated: totalUpdated,
                rows_failed: totalFailed,
                execution_time: importStartTime ? ((Date.now() - importStartTime) / 1000) : 0,
                status: finalStatus
            }
        });

        // If completed or failed, show Finish button
        $('#smip-progress-header').text(finalStatus === 'completed' ? SMIP.strings.completed : SMIP.strings.failed);
        $('#smip-btn-pause-import').hide();
        $('#smip-btn-resume-import').hide();
        $('#smip-btn-cancel-import').hide();
        $('#smip-btn-finish-import').show();
    }

    // Backend Cancel
    function cancelImportOnBackend() {
        $.ajax({
            url: SMIP.ajax_url,
            type: 'POST',
            data: {
                action: 'smip_cancel_import',
                security: SMIP.nonce,
                import_id: importId,
                file_path: filePath
            },
            success: function() {
                $('#smip-progress-header').text(SMIP.strings.cancelled);
                $('#smip-btn-pause-import').hide();
                $('#smip-btn-resume-import').hide();
                $('#smip-btn-cancel-import').hide();
                $('#smip-btn-finish-import').show();
            }
        });
    }

    // 9. Pause / Resume / Cancel Controls
    $('#smip-btn-pause-import').on('click', function() {
        isPaused = true;
        $(this).hide();
        $('#smip-btn-resume-import').show();
    });

    $('#smip-btn-resume-import').on('click', function() {
        isPaused = false;
        $(this).hide();
        $('#smip-btn-pause-import').show();
        writeToConsole('Resuming import execution...');
        executeBatch();
    });

    $('#smip-btn-cancel-import').on('click', function() {
        if (confirm('Are you sure you want to halt the import process? Any updates already made will remain, but you can rollback from the History tab.')) {
            isCancelled = true;
            if (isPaused) {
                // If paused, we trigger cancel directly since recurse loop is idle
                cancelImportOnBackend();
            }
        }
    });

    $('#smip-btn-finish-import').on('click', function() {
        // Redirect to history tab
        window.location.hash = '#history';
        location.reload();
    });

    // 10. Helper methods
    function getMappingData() {
        var mapping = {};
        $('.smip-field-selector').each(function() {
            var $select = $(this);
            var header = $select.attr('name').match(/\[(.*?)\]/)[1];
            var val = $select.val();
            
            if (val === 'custom') {
                var customVal = $('input[name="custom_mapping[' + header + ']"]').val();
                if (customVal && customVal.trim() !== '') {
                    mapping[header] = 'custom:' + customVal.trim();
                } else {
                    mapping[header] = '';
                }
            } else {
                mapping[header] = val;
            }
        });
        return mapping;
    }

    function writeToConsole(message, type) {
        var $console = $('#smip-import-console-logs');
        var prefix = '[' + new Date().toLocaleTimeString() + '] ';
        var text = prefix + message + '\n';
        $console.append(text);
        
        // Scroll to bottom
        $console.scrollTop($console[0].scrollHeight);
    }

    function escapeHtml(text) {
        if (!text) return '';
        var map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return text.replace(/[&<>"']/g, function(m) { return map[m]; });
    }
});
