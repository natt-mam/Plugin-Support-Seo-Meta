/**
 * SEO Meta Importer Pro - Main Admin Controller Script
 */

jQuery(document).ready(function($) {
    'use strict';

    // 1. Tab Switching Logic
    function switchTab(hash) {
        if (!hash) hash = '#dashboard';
        
        var tabName = hash.replace('#', '');
        var $tabLink = $('.smip-nav-tab[data-tab="' + tabName + '"]');
        var $pane = $('#tab-' + tabName);

        if ($tabLink.length && $pane.length) {
            $('.smip-nav-tab').removeClass('active');
            $('.smip-tab-pane').removeClass('active');

            $tabLink.addClass('active');
            $pane.addClass('active');

            window.location.hash = hash;
        }
    }

    // Bind hashchange event
    $(window).on('hashchange', function() {
        switchTab(window.location.hash);
    });

    // Initial load switch
    if (window.location.hash) {
        switchTab(window.location.hash);
    }

    // Tab link click
    $('.smip-nav-tab').on('click', function(e) {
        e.preventDefault();
        var hash = $(this).attr('href');
        switchTab(hash);
    });

    // Quick links trigger from cards
    $(document).on('click', '.smip-trigger-tab-link', function(e) {
        e.preventDefault();
        var target = $(this).data('target');
        switchTab('#' + target);
    });

    // 2. Rollback (Undo Import) Handler
    $(document).on('click', '.smip-btn-rollback', function(e) {
        e.preventDefault();
        var $btn = $(this);
        var importId = $btn.data('id');

        if (!confirm(SMIP.strings.confirm_rollback)) {
            return;
        }

        $btn.prop('disabled', true).html('<span class="dashicons dashicons-update spin"></span> Reverting...');

        $.ajax({
            url: SMIP.ajax_url,
            type: 'POST',
            data: {
                action: 'smip_rollback_import',
                security: SMIP.nonce,
                import_id: importId
            },
            success: function(response) {
                if (response.success) {
                    alert(response.data.message);
                    location.reload();
                } else {
                    alert(response.data.message || 'Failed to rollback import.');
                    $btn.prop('disabled', false).html('<span class="dashicons dashicons-undo"></span> Rollback (Undo)');
                }
            },
            error: function() {
                alert('Server error occurred during rollback.');
                $btn.prop('disabled', false).html('<span class="dashicons dashicons-undo"></span> Rollback (Undo)');
            }
        });
    });

    // 3. Clear Logs Handler
    $('#smip-btn-clear-logs').on('click', function(e) {
        e.preventDefault();
        var $btn = $(this);

        if (!confirm('Are you sure you want to clear all logs?')) {
            return;
        }

        $btn.prop('disabled', true);

        $.ajax({
            url: SMIP.ajax_url,
            type: 'POST',
            data: {
                action: 'smip_clear_logs',
                security: SMIP.nonce
            },
            success: function(response) {
                if (response.success) {
                    $('#smip-logs-view').text('No logs available.');
                } else {
                    alert(response.data.message || 'Failed to clear logs.');
                }
                $btn.prop('disabled', false);
            },
            error: function() {
                alert('Server error occurred.');
                $btn.prop('disabled', false);
            }
        });
    });

    // 4. Refresh Logs Handler
    $('#smip-btn-refresh-logs').on('click', function(e) {
        e.preventDefault();
        location.reload();
    });

    // 5. Google Sheets Manual Sync Handler
    $('#smip-btn-sync-sheets-now').on('click', function(e) {
        e.preventDefault();
        var $btn = $(this);
        $btn.prop('disabled', true).html('<span class="dashicons dashicons-update spin"></span> Downloading Sheet...');

        $.ajax({
            url: SMIP.ajax_url,
            type: 'POST',
            data: {
                action: 'smip_sync_google_sheets',
                security: SMIP.nonce
            },
            success: function(response) {
                if (response.success) {
                    // Redirect directly to the Import Wizard tab and load the file!
                    var data = response.data;
                    
                    // Trigger custom event or call global initializer on importer js
                    window.SMIP_GoogleSheetLoaded = data;
                    $(document).trigger('smip_google_sheet_fetched', [data]);

                    // Switch tab to CSV import
                    switchTab('#import-csv');
                } else {
                    alert(response.data.message || 'Failed to sync Google Sheet.');
                }
                $btn.prop('disabled', false).html('<span class="dashicons dashicons-update"></span> Import & Sync Now');
            },
            error: function() {
                alert('Server error while downloading Google Sheet.');
                $btn.prop('disabled', false).html('<span class="dashicons dashicons-update"></span> Import & Sync Now');
            }
        });
    });

    // 6. Export Metadata Handler
    $('#smip-btn-start-export').on('click', function(e) {
        e.preventDefault();
        var $btn = $(this);
        var $spinner = $('#smip-export-spinner');
        var $downloadBox = $('#smip-export-download-box');

        var postTypes = [];
        $('input[name="smip-export-post-types"]:checked').each(function() {
            postTypes.push($(this).val());
        });

        var taxonomies = [];
        $('input[name="smip-export-taxonomies"]:checked').each(function() {
            taxonomies.push($(this).val());
        });

        if (postTypes.length === 0 && taxonomies.length === 0) {
            alert('Please select at least one post type or taxonomy to export.');
            return;
        }

        $btn.prop('disabled', true);
        $spinner.show();
        $downloadBox.hide();

        $.ajax({
            url: SMIP.ajax_url,
            type: 'POST',
            data: {
                action: 'smip_export_metadata',
                security: SMIP.nonce,
                post_types: postTypes,
                taxonomies: taxonomies,
                seo_plugin: $('#smip-export-seo-plugin').val()
            },
            success: function(response) {
                if (response.success) {
                    $('#smip-export-download-link').attr('href', response.data.download_url);
                    $downloadBox.show();
                } else {
                    alert(response.data.message || 'Export generation failed.');
                }
                $btn.prop('disabled', false);
                $spinner.hide();
            },
            error: function() {
                alert('Server error occurred during export.');
                $btn.prop('disabled', false);
                $spinner.hide();
            }
        });
    });
});
