<?php
namespace SEOMetaImporterPro\Admin;

defined('ABSPATH') || exit;

class Admin_Menu {
    private static ?Admin_Menu $instance = null;

    public static function get_instance(): Admin_Menu {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {}

    /**
     * Register Admin Menu.
     */
    public function register(): void {
        add_menu_page(
            __('SEO Meta Importer Pro', 'seo-meta-importer-pro'),
            __('SEO Importer Pro', 'seo-meta-importer-pro'),
            'manage_options',
            'seo-meta-importer-pro',
            [$this, 'render_admin_page'],
            'dashicons-database-import',
            99
        );
    }

    /**
     * Render Admin Page.
     */
    public function render_admin_page(): void {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'seo-meta-importer-pro'));
        }

        // Process Settings Saves
        $message = '';
        $message_type = 'success';

        if (isset($_POST['smip_save_settings'])) {
            if (!check_admin_referer('smip_settings_save', 'smip_settings_nonce')) {
                wp_die(__('Security verification failed.', 'seo-meta-importer-pro'));
            }

            update_option('smip_batch_size', intval($_POST['smip_batch_size']));
            update_option('smip_max_rows', intval($_POST['smip_max_rows']));
            update_option('smip_csv_delimiter', sanitize_text_field($_POST['smip_csv_delimiter']));
            update_option('smip_encoding', sanitize_text_field($_POST['smip_encoding']));
            update_option('smip_default_seo_plugin', sanitize_text_field($_POST['smip_default_seo_plugin']));
            update_option('smip_timezone', sanitize_text_field($_POST['smip_timezone']));
            update_option('smip_debug_mode', sanitize_text_field($_POST['smip_debug_mode']));

            $message = __('Settings saved successfully.', 'seo-meta-importer-pro');
        } elseif (isset($_POST['smip_save_sheets_settings'])) {
            if (!check_admin_referer('smip_google_sheets_save', 'smip_sheets_nonce')) {
                wp_die(__('Security verification failed.', 'seo-meta-importer-pro'));
            }

            update_option('smip_google_sheet_url', esc_url_raw($_POST['smip_google_sheet_url']));
            update_option('smip_google_sheets_api_key', sanitize_text_field($_POST['smip_google_sheets_api_key']));
            update_option('smip_auto_sync', sanitize_text_field($_POST['smip_auto_sync']));

            // Reschedule WP Cron Sync hook
            \SEOMetaImporterPro\Google\Sheets_Sync::reschedule();

            $message = __('Google Sheets settings saved and sync rescheduled.', 'seo-meta-importer-pro');
        }

        if (!empty($message)) {
            echo sprintf(
                '<div class="notice notice-%s is-dismissible" style="margin: 15px 0 0 0;"><p><strong>%s</strong></p></div>',
                esc_attr($message_type),
                esc_html($message)
            );
        }

        // Active tab check
        $active_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'dashboard';
        
        // Load main wrapper template
        $plugin_path = dirname(__DIR__);
        require_once $plugin_path . '/templates/admin-wrapper.php';
    }
}
