<?php
namespace SEOMetaImporterPro\Admin;

defined('ABSPATH') || exit;

class Admin_Ajax {
    /**
     * Register AJAX hooks.
     */
    public static function register(): void {
        $actions = [
            'upload_csv',
            'analyze_preview',
            'start_import',
            'import_batch',
            'complete_import',
            'cancel_import',
            'export_metadata',
            'download_export',
            'sync_google_sheets',
            'rollback_import',
            'clear_logs',
            'download_history',
        ];

        foreach ($actions as $action) {
            add_action('wp_ajax_smip_' . $action, [self::class, 'handle_' . $action]);
        }
    }

    /**
     * Verify safety of the request.
     */
    private static function verify_request(): void {
        check_ajax_referer('smip_admin_nonce', 'security');
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'seo-meta-importer-pro')], 403);
        }
    }

    /**
     * Handle CSV upload and header reading.
     */
    public static function handle_upload_csv(): void {
        self::verify_request();

        if (empty($_FILES['file'])) {
            wp_send_json_error(['message' => __('No file uploaded.', 'seo-meta-importer-pro')]);
        }

        $file = $_FILES['file'];
        if ($file['error'] !== UPLOAD_ERR_OK) {
            wp_send_json_error(['message' => __('File upload error.', 'seo-meta-importer-pro')]);
        }

        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        if (strtolower($ext) !== 'csv') {
            wp_send_json_error(['message' => __('Please upload a valid CSV file.', 'seo-meta-importer-pro')]);
        }

        // Move to secure temp location in uploads
        $upload_dir = wp_upload_dir();
        $temp_dir = $upload_dir['basedir'] . '/smip-temp';
        if (!file_exists($temp_dir)) {
            wp_mkdir_p($temp_dir);
            file_put_contents($temp_dir . '/index.html', '');
            file_put_contents($temp_dir . '/.htaccess', 'Deny from all');
        }

        $temp_file = $temp_dir . '/upload-' . uniqid() . '.csv';
        if (!move_uploaded_file($file['tmp_name'], $temp_file)) {
            wp_send_json_error(['message' => __('Failed to save uploaded file.', 'seo-meta-importer-pro')]);
        }

        $delimiter = sanitize_text_field($_POST['delimiter'] ?? ',');
        $encoding = sanitize_text_field($_POST['encoding'] ?? 'UTF-8');

        $headers = \SEOMetaImporterPro\Import\Csv_Parser::get_headers($temp_file, $delimiter, $encoding);
        $total_rows = \SEOMetaImporterPro\Import\Csv_Parser::get_total_rows($temp_file);

        if (empty($headers)) {
            unlink($temp_file);
            wp_send_json_error(['message' => __('Unable to parse CSV headers. Check your delimiter and encoding settings.', 'seo-meta-importer-pro')]);
        }

        wp_send_json_success([
            'file_path'  => $temp_file,
            'headers'    => $headers,
            'total_rows' => $total_rows,
        ]);
    }

    /**
     * Run full pre-import analysis.
     */
    public static function handle_analyze_preview(): void {
        self::verify_request();

        $file_path = sanitize_text_field($_POST['file_path'] ?? '');
        $mapping_raw = $_POST['mapping'] ?? [];
        
        if (empty($file_path) || !file_exists($file_path)) {
            wp_send_json_error(['message' => __('Temporary file not found.', 'seo-meta-importer-pro')]);
        }

        $mapping = [];
        foreach ($mapping_raw as $csv_col => $field_key) {
            $mapping[sanitize_text_field($csv_col)] = sanitize_text_field($field_key);
        }

        $settings = [
            'seo_plugin' => sanitize_text_field($_POST['seo_plugin'] ?? 'auto'),
            'filters'    => [
                'post_types' => isset($_POST['post_types']) ? array_map('sanitize_text_field', (array)$_POST['post_types']) : [],
                'taxonomies' => isset($_POST['taxonomies']) ? array_map('sanitize_text_field', (array)$_POST['taxonomies']) : [],
            ],
        ];

        $engine = new \SEOMetaImporterPro\Import\Import_Engine($file_path, $mapping, $settings);
        $analysis = $engine->analyze_import(10); // Analyze and return first 10 for preview

        if (isset($analysis['error'])) {
            wp_send_json_error(['message' => $analysis['error']]);
        }

        wp_send_json_success($analysis);
    }

    /**
     * Create database entry to track import run.
     */
    public static function handle_start_import(): void {
        self::verify_request();

        $filename = sanitize_text_field($_POST['filename'] ?? 'import.csv');
        $seo_plugin = sanitize_text_field($_POST['seo_plugin'] ?? 'auto');
        $import_type = sanitize_text_field($_POST['import_type'] ?? 'csv');

        $import_id = \SEOMetaImporterPro\Includes\Database::insert_history([
            'filename'    => $filename,
            'seo_plugin'  => $seo_plugin,
            'status'      => 'running',
            'import_type' => $import_type,
        ]);

        if ($import_id === 0) {
            wp_send_json_error(['message' => __('Failed to initialize import history record.', 'seo-meta-importer-pro')]);
        }

        wp_send_json_success(['import_id' => $import_id]);
    }

    /**
     * Process a batch of rows.
     */
    public static function handle_import_batch(): void {
        self::verify_request();

        $file_path = sanitize_text_field($_POST['file_path'] ?? '');
        $import_id = intval($_POST['import_id'] ?? 0);
        $offset = intval($_POST['offset'] ?? 0);
        $limit = intval($_POST['limit'] ?? 100);
        $dry_run = isset($_POST['dry_run']) && $_POST['dry_run'] === 'true';
        $mapping_raw = $_POST['mapping'] ?? [];

        if (empty($file_path) || !file_exists($file_path)) {
            wp_send_json_error(['message' => __('CSV file not found.', 'seo-meta-importer-pro')]);
        }

        $mapping = [];
        foreach ($mapping_raw as $csv_col => $field_key) {
            $mapping[sanitize_text_field($csv_col)] = sanitize_text_field($field_key);
        }

        $settings = [
            'seo_plugin' => sanitize_text_field($_POST['seo_plugin'] ?? 'auto'),
            'dry_run'    => $dry_run,
            'filters'    => [
                'post_types' => isset($_POST['post_types']) ? array_map('sanitize_text_field', (array)$_POST['post_types']) : [],
                'taxonomies' => isset($_POST['taxonomies']) ? array_map('sanitize_text_field', (array)$_POST['taxonomies']) : [],
            ],
        ];

        $engine = new \SEOMetaImporterPro\Import\Import_Engine($file_path, $mapping, $settings);
        $engine->set_import_id($import_id);

        $result = $engine->process_batch($offset, $limit);
        if (is_wp_error($result)) {
            wp_send_json_error(['message' => $result->get_error_message()]);
        }

        wp_send_json_success($result);
    }

    /**
     * Mark an import as completed or failed and persist final counters.
     */
    public static function handle_complete_import(): void {
        self::verify_request();

        $import_id = intval($_POST['import_id'] ?? 0);
        if ($import_id <= 0) {
            wp_send_json_error(['message' => __('Invalid import ID.', 'seo-meta-importer-pro')]);
        }

        $status = sanitize_key($_POST['status'] ?? 'completed');
        if (!in_array($status, ['completed', 'failed'], true)) {
            $status = 'completed';
        }

        \SEOMetaImporterPro\Includes\Database::update_history($import_id, [
            'rows_updated'   => intval($_POST['rows_updated'] ?? 0),
            'rows_failed'    => intval($_POST['rows_failed'] ?? 0),
            'execution_time' => max(0, floatval($_POST['execution_time'] ?? 0)),
            'status'         => $status,
        ]);

        $file_path = sanitize_text_field($_POST['file_path'] ?? '');
        if (!empty($file_path) && file_exists($file_path)) {
            unlink($file_path);
        }

        wp_send_json_success();
    }

    /**
     * Cancel an ongoing import.
     */
    public static function handle_cancel_import(): void {
        self::verify_request();

        $import_id = intval($_POST['import_id'] ?? 0);
        if ($import_id > 0) {
            \SEOMetaImporterPro\Includes\Database::update_history($import_id, [
                'status' => 'cancelled'
            ]);
        }

        // Clean up uploaded file if specified
        $file_path = sanitize_text_field($_POST['file_path'] ?? '');
        if (!empty($file_path) && file_exists($file_path)) {
            unlink($file_path);
        }

        wp_send_json_success();
    }

    /**
     * Trigger bulk SEO metadata export.
     */
    public static function handle_export_metadata(): void {
        self::verify_request();

        $filters = [
            'post_types' => isset($_POST['post_types']) ? array_map('sanitize_text_field', (array)$_POST['post_types']) : [],
            'taxonomies' => isset($_POST['taxonomies']) ? array_map('sanitize_text_field', (array)$_POST['taxonomies']) : [],
        ];
        $seo_plugin = sanitize_text_field($_POST['seo_plugin'] ?? 'auto');

        $result = \SEOMetaImporterPro\Export\Export_Engine::generate_export($filters, $seo_plugin);
        if (is_wp_error($result)) {
            wp_send_json_error(['message' => $result->get_error_message()]);
        }

        $download_url = add_query_arg(
            [
                'action'   => 'smip_download_export',
                'security' => wp_create_nonce('smip_admin_nonce'),
                'file'     => basename($result),
            ],
            admin_url('admin-ajax.php')
        );

        wp_send_json_success(['download_url' => $download_url]);
    }

    /**
     * Stream a generated export file through an authenticated endpoint.
     */
    public static function handle_download_export(): void {
        check_admin_referer('smip_admin_nonce', 'security');
        if (!current_user_can('manage_options')) {
            wp_die(__('Permission denied.', 'seo-meta-importer-pro'));
        }

        $filename = sanitize_file_name(wp_unslash($_GET['file'] ?? ''));
        if (empty($filename)) {
            wp_die(__('Missing export file.', 'seo-meta-importer-pro'));
        }

        $upload_dir = wp_upload_dir();
        $file_path = trailingslashit($upload_dir['basedir']) . 'smip-exports/' . $filename;
        if (!file_exists($file_path) || !is_readable($file_path)) {
            wp_die(__('Export file not found.', 'seo-meta-importer-pro'));
        }

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=' . $filename);
        header('Pragma: no-cache');
        header('Expires: 0');

        readfile($file_path);
        exit;
    }

    /**
     * Trigger manual Google Sheets Sync.
     */
    public static function handle_sync_google_sheets(): void {
        self::verify_request();

        $url = get_option('smip_google_sheet_url', '');
        if (empty($url)) {
            wp_send_json_error(['message' => __('Please configure and save Google Sheet URL in Settings first.', 'seo-meta-importer-pro')]);
        }

        // Fetch sheet
        $api_key = get_option('smip_google_sheets_api_key', '');
        $file_path = \SEOMetaImporterPro\Google\Sheets_Client::download_sheet_to_file($url, $api_key);
        
        if (is_wp_error($file_path)) {
            wp_send_json_error(['message' => $file_path->get_error_message()]);
        }

        $headers = \SEOMetaImporterPro\Import\Csv_Parser::get_headers($file_path);
        $total_rows = \SEOMetaImporterPro\Import\Csv_Parser::get_total_rows($file_path);

        wp_send_json_success([
            'file_path'  => $file_path,
            'headers'    => $headers,
            'total_rows' => $total_rows,
            'filename'   => basename($url),
        ]);
    }

    /**
     * Revert import metadata updates.
     */
    public static function handle_rollback_import(): void {
        self::verify_request();

        $import_id = intval($_POST['import_id'] ?? 0);
        if ($import_id === 0) {
            wp_send_json_error(['message' => __('Invalid import ID.', 'seo-meta-importer-pro')]);
        }

        $result = \SEOMetaImporterPro\Rollback\Rollback_Manager::rollback_import($import_id);
        if (is_wp_error($result)) {
            wp_send_json_error(['message' => $result->get_error_message()]);
        }

        wp_send_json_success([
            'message' => sprintf(__('Rollback successful! Restored %d fields.', 'seo-meta-importer-pro'), $result)
        ]);
    }

    /**
     * Clear application debug logs.
     */
    public static function handle_clear_logs(): void {
        self::verify_request();

        $logger = new \SEOMetaImporterPro\Logger\Logger();
        if ($logger->clear_logs()) {
            wp_send_json_success(['message' => __('Logs cleared successfully.', 'seo-meta-importer-pro')]);
        } else {
            wp_send_json_error(['message' => __('Failed to clear logs.', 'seo-meta-importer-pro')]);
        }
    }

    /**
     * Stream import history CSV file.
     */
    public static function handle_download_history(): void {
        // Since we are clicking a direct link, use standard check_admin_referer or check_ajax_referer with GET query arg
        check_admin_referer('smip_admin_nonce', 'security');
        if (!current_user_can('manage_options')) {
            wp_die(__('Permission denied.', 'seo-meta-importer-pro'));
        }

        $file_path = \SEOMetaImporterPro\Logger\Logger::generate_history_csv();
        if (!$file_path || !file_exists($file_path)) {
            wp_die(__('No history entries to download.', 'seo-meta-importer-pro'));
        }

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=seo-meta-importer-history-' . date('Y-m-d') . '.csv');
        header('Pragma: no-cache');
        header('Expires: 0');

        readfile($file_path);
        unlink($file_path);
        exit;
    }
}
