<?php
namespace SEOMetaImporterPro\Admin;

defined('ABSPATH') || exit;

class Admin_Assets {
    /**
     * Enqueue Admin Assets.
     */
    public static function enqueue(string $plugin_file): void {
        $plugin_url = plugin_dir_url($plugin_file);

        // Enqueue Google Font (Inter) for premium feel
        wp_enqueue_style(
            'smip-google-font-inter',
            'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap',
            [],
            '1.0.0'
        );

        // Enqueue custom CSS
        wp_enqueue_style(
            'smip-admin-styles',
            $plugin_url . 'assets/css/admin.css',
            [],
            '1.0.0'
        );

        // Enqueue custom JavaScript for general tab logic and mappings
        wp_enqueue_script(
            'smip-admin-js',
            $plugin_url . 'assets/js/admin.js',
            ['jquery'],
            '1.0.0',
            true
        );

        // Enqueue custom JavaScript specifically for the AJAX batch import engine
        wp_enqueue_script(
            'smip-importer-js',
            $plugin_url . 'assets/js/importer.js',
            ['jquery'],
            '1.0.0',
            true
        );

        // Localize scripts for AJAX communication
        $localized_data = [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('smip_admin_nonce'),
            'strings'  => [
                'confirm_rollback' => __('Are you sure you want to revert this import? This will overwrite existing metadata values with the backed-up values.', 'seo-meta-importer-pro'),
                'importing'        => __('Importing rows...', 'seo-meta-importer-pro'),
                'completed'        => __('Import completed!', 'seo-meta-importer-pro'),
                'failed'           => __('Import failed!', 'seo-meta-importer-pro'),
                'paused'           => __('Import paused.', 'seo-meta-importer-pro'),
                'cancelled'        => __('Import cancelled.', 'seo-meta-importer-pro'),
                'analyzing'        => __('Analyzing file, please wait...', 'seo-meta-importer-pro'),
                'no_mapping'       => __('Please map at least one CSV column to a WordPress field.', 'seo-meta-importer-pro'),
                'select_file'      => __('Please select a valid CSV file first.', 'seo-meta-importer-pro'),
            ]
        ];

        wp_localize_script('smip-admin-js', 'SMIP', $localized_data);
        wp_localize_script('smip-importer-js', 'SMIP', $localized_data);
    }
}
