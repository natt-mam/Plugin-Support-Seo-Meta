<?php
namespace SEOMetaImporterPro\Includes;

defined('ABSPATH') || exit;

class Deactivator {
    /**
     * Deactivate the plugin.
     */
    public static function deactivate(): void {
        // Clear cron events
        wp_clear_scheduled_hook('smip_google_sheets_sync_cron');
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }
}
