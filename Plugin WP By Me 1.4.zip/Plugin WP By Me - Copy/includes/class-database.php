<?php
namespace SEOMetaImporterPro\Includes;

defined('ABSPATH') || exit;

class Database {
    /**
     * Get history table name.
     */
    public static function get_history_table_name(): string {
        global $wpdb;
        return $wpdb->prefix . 'seo_meta_import_history';
    }

    /**
     * Get rollback table name.
     */
    public static function get_rollback_table_name(): string {
        global $wpdb;
        return $wpdb->prefix . 'seo_meta_rollback';
    }

    /**
     * Create custom tables in database.
     */
    public static function create_tables(): void {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        $history_table = self::get_history_table_name();
        $rollback_table = self::get_rollback_table_name();

        $sql_history = "CREATE TABLE $history_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            date datetime NOT NULL,
            user_id bigint(20) NOT NULL,
            filename varchar(255) NOT NULL,
            rows_updated int(11) DEFAULT 0,
            rows_failed int(11) DEFAULT 0,
            seo_plugin varchar(50) NOT NULL,
            execution_time float DEFAULT 0,
            status varchar(20) NOT NULL,
            import_type varchar(20) NOT NULL,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        $sql_rollback = "CREATE TABLE $rollback_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            import_id bigint(20) NOT NULL,
            object_id bigint(20) NOT NULL,
            object_type varchar(20) NOT NULL, -- 'post' or 'term'
            meta_key varchar(255) NOT NULL,
            old_value longtext,
            PRIMARY KEY  (id),
            KEY import_id (import_id)
        ) $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql_history);
        dbDelta($sql_rollback);
    }

    /**
     * Insert import history record.
     */
    public static function insert_history(array $data): int {
        global $wpdb;
        $table = self::get_history_table_name();
        
        $inserted = $wpdb->insert(
            $table,
            [
                'date'           => current_time('mysql'),
                'user_id'        => get_current_user_id(),
                'filename'       => sanitize_text_field($data['filename'] ?? ''),
                'rows_updated'   => intval($data['rows_updated'] ?? 0),
                'rows_failed'    => intval($data['rows_failed'] ?? 0),
                'seo_plugin'     => sanitize_text_field($data['seo_plugin'] ?? ''),
                'execution_time' => floatval($data['execution_time'] ?? 0),
                'status'         => sanitize_text_field($data['status'] ?? 'pending'),
                'import_type'    => sanitize_text_field($data['import_type'] ?? 'csv'),
            ],
            ['%s', '%d', '%s', '%d', '%d', '%s', '%f', '%s', '%s']
        );

        if (!$inserted) {
            return 0;
        }

        return (int) $wpdb->insert_id;
    }

    /**
     * Update history record.
     */
    public static function update_history(int $id, array $data): bool {
        global $wpdb;
        $table = self::get_history_table_name();
        
        $fields = [];
        $formats = [];

        if (isset($data['rows_updated'])) {
            $fields['rows_updated'] = intval($data['rows_updated']);
            $formats[] = '%d';
        }
        if (isset($data['rows_failed'])) {
            $fields['rows_failed'] = intval($data['rows_failed']);
            $formats[] = '%d';
        }
        if (isset($data['execution_time'])) {
            $fields['execution_time'] = floatval($data['execution_time']);
            $formats[] = '%f';
        }
        if (isset($data['status'])) {
            $fields['status'] = sanitize_text_field($data['status']);
            $formats[] = '%s';
        }
        if (isset($data['filename'])) {
            $fields['filename'] = sanitize_text_field($data['filename']);
            $formats[] = '%s';
        }
        if (isset($data['seo_plugin'])) {
            $fields['seo_plugin'] = sanitize_text_field($data['seo_plugin']);
            $formats[] = '%s';
        }

        if (empty($fields)) {
            return false;
        }

        $result = $wpdb->update(
            $table,
            $fields,
            ['id' => $id],
            $formats,
            ['%d']
        );

        return $result !== false;
    }

    /**
     * Get history items.
     */
    public static function get_history(int $limit = 10, int $offset = 0): array {
        global $wpdb;
        $table = self::get_history_table_name();
        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM $table ORDER BY id DESC LIMIT %d OFFSET %d",
                $limit,
                $offset
            ),
            ARRAY_A
        );
    }

    /**
     * Get total history records count.
     */
    public static function get_history_count(): int {
        global $wpdb;
        $table = self::get_history_table_name();
        return (int) $wpdb->get_var("SELECT COUNT(*) FROM $table");
    }

    /**
     * Get single history item.
     */
    public static function get_history_item(int $id): ?array {
        global $wpdb;
        $table = self::get_history_table_name();
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %d", $id), ARRAY_A);
        return $row ?: null;
    }

    /**
     * Insert rollback meta record.
     */
    public static function insert_rollback(int $import_id, int $object_id, string $object_type, string $meta_key, ?string $old_value): bool {
        global $wpdb;
        $table = self::get_rollback_table_name();
        $result = $wpdb->insert(
            $table,
            [
                'import_id'   => $import_id,
                'object_id'   => $object_id,
                'object_type' => $object_type,
                'meta_key'    => $meta_key,
                'old_value'   => $old_value,
            ],
            ['%d', '%d', '%s', '%s', '%s']
        );
        return $result !== false;
    }

    /**
     * Retrieve rollback items for a specific import.
     */
    public static function get_rollback_items(int $import_id): array {
        global $wpdb;
        $table = self::get_rollback_table_name();
        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM $table WHERE import_id = %d",
                $import_id
            ),
            ARRAY_A
        );
    }

    /**
     * Delete rollback items for a specific import.
     */
    public static function delete_rollback_items(int $import_id): bool {
        global $wpdb;
        $table = self::get_rollback_table_name();
        $result = $wpdb->delete($table, ['import_id' => $import_id], ['%d']);
        return $result !== false;
    }

    /**
     * Delete a single history record.
     */
    public static function delete_history_item(int $id): bool {
        global $wpdb;
        $table = self::get_history_table_name();
        $result = $wpdb->delete($table, ['id' => $id], ['%d']);
        return $result !== false;
    }
}
