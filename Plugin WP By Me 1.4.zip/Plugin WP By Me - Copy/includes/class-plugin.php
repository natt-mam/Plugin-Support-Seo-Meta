<?php
namespace SEOMetaImporterPro\Includes;

defined('ABSPATH') || exit;

class Plugin {
    /**
     * Instance of the plugin class.
     */
    private static ?Plugin $instance = null;

    /**
     * Path to the main plugin file.
     */
    private string $plugin_file;

    /**
     * Get singleton instance.
     */
    public static function get_instance(string $plugin_file = ''): Plugin {
        if (null === self::$instance) {
            self::$instance = new self($plugin_file);
        }
        return self::$instance;
    }

    /**
     * Constructor.
     */
    private function __construct(string $plugin_file) {
        $this->plugin_file = $plugin_file;
        $this->init_hooks();
    }

    /**
     * Initialize WordPress hooks.
     */
    private function init_hooks(): void {
        // Activation & Deactivation
        register_activation_hook($this->plugin_file, [__NAMESPACE__ . '\\Activator', 'activate']);
        register_deactivation_hook($this->plugin_file, [__NAMESPACE__ . '\\Deactivator', 'deactivate']);

        // Core Init
        add_action('init', [$this, 'init']);

        // Admin initialization
        if (is_admin()) {
            add_action('admin_menu', [$this, 'init_admin_menu']);
            add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_assets']);
            // Register AJAX handlers
            \SEOMetaImporterPro\Admin\Admin_Ajax::register();
        }

        // REST API
        add_action('rest_api_init', [$this, 'register_rest_routes']);

        // WP-CLI
        if (defined('WP_CLI') && WP_CLI) {
            add_action('cli_init', [$this, 'register_cli_commands']);
        }
    }

    /**
     * Hook run on WordPress init.
     */
    public function init(): void {
        // Handle Cron scheduling for Google Sheets Sync
        \SEOMetaImporterPro\Google\Sheets_Sync::register_cron_actions();
    }

    /**
     * Initialize Admin Menu.
     */
    public function init_admin_menu(): void {
        \SEOMetaImporterPro\Admin\Admin_Menu::get_instance()->register();
    }

    /**
     * Enqueue Admin Assets.
     */
    public function enqueue_admin_assets(string $hook): void {
        if (strpos($hook, 'seo-meta-importer-pro') !== false) {
            \SEOMetaImporterPro\Admin\Admin_Assets::enqueue($this->plugin_file);
        }
    }

    /**
     * Register REST API Routes.
     */
    public function register_rest_routes(): void {
        $controller = new \SEOMetaImporterPro\API\Rest_Controller();
        $controller->register_routes();
    }

    /**
     * Register WP-CLI Commands.
     */
    public function register_cli_commands(): void {
        \SEOMetaImporterPro\CLI\Cli_Commands::register();
    }

    /**
     * Get the plugin base file path.
     */
    public function get_plugin_file(): string {
        return $this->plugin_file;
    }
}
