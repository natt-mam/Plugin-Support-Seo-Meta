<?php
namespace SEOMetaImporterPro\Includes;

defined('ABSPATH') || exit;

class Autoloader {
    /**
     * Namespace prefix.
     */
    private const PREFIX = 'SEOMetaImporterPro\\';

    /**
     * Base directory.
     */
    private string $base_dir;

    /**
     * Register autoloader.
     */
    public static function register(string $base_file): void {
        $autoloader = new self(dirname($base_file));
        spl_autoload_register([$autoloader, 'autoload']);
    }

    /**
     * Constructor.
     */
    public function __construct(string $base_dir) {
        $this->base_dir = trailingslashit($base_dir);
    }

    /**
     * Autoload callback.
     */
    public function autoload(string $class): void {
        if (strpos($class, self::PREFIX) !== 0) {
            return;
        }

        // Relative class name
        $relative_class = substr($class, strlen(self::PREFIX));
        $parts = explode('\\', $relative_class);
        $class_name = array_pop($parts);

        // Convert namespace parts to lowercase directory structure
        $dir_parts = array_map(function($part) {
            return strtolower(str_replace('_', '-', $part));
        }, $parts);

        $dir_path = $this->base_dir . implode('/', $dir_parts);
        if (!empty($dir_parts)) {
            $dir_path .= '/';
        }

        // Try standard WordPress name: class-classname.php
        $wp_class_file = 'class-' . strtolower(str_replace('_', '-', $class_name)) . '.php';
        if (file_exists($dir_path . $wp_class_file)) {
            require_once $dir_path . $wp_class_file;
            return;
        }

        // Try standard PSR-4 name: ClassName.php
        $psr_class_file = $class_name . '.php';
        if (file_exists($dir_path . $psr_class_file)) {
            require_once $dir_path . $psr_class_file;
            return;
        }
    }
}
