<?php
namespace SEOMetaImporterPro\Includes;

defined('ABSPATH') || exit;

class Activator {
    /**
     * Activate the plugin.
     */
    public static function activate(): void {
        // Ensure Database Tables exist
        Database::create_tables();

        // Register default settings if not already set
        self::initialize_defaults();

        // Flush rewrite rules
        flush_rewrite_rules();
    }

    /**
     * Set up default options.
     */
    private static function initialize_defaults(): void {
        $defaults = [
            'batch_size'         => 100,
            'max_rows'           => 100000,
            'auto_sync'          => 'manual',
            'timezone'           => get_option('timezone_string') ?: 'UTC',
            'default_seo_plugin' => 'auto',
            'csv_delimiter'      => ',',
            'encoding'           => 'UTF-8',
            'debug_mode'         => 'no',
        ];

        foreach ($defaults as $key => $val) {
            $opt_name = 'smip_' . $key;
            if (false === get_option($opt_name)) {
                update_option($opt_name, $val);
            }
        }
    }
}
