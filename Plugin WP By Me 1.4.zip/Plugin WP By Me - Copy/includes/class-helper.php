<?php
namespace SEOMetaImporterPro\Includes;

defined('ABSPATH') || exit;

class Helper {
    /**
     * Resolve an identifier (URL, Slug, ID) to a WordPress Object (Post or Term).
     * 
     * @return array|null [ 'id' => int, 'type' => 'post'|'term', 'sub_type' => string ]
     */
    public static function resolve_identifier(string $identifier, array $allowed_post_types = [], array $allowed_taxonomies = []): ?array {
        $identifier = trim($identifier);
        if (empty($identifier)) {
            return null;
        }

        // 1. Check if numeric ID
        if (is_numeric($identifier)) {
            $id = intval($identifier);
            // Check if it's a post
            $post = get_post($id);
            if ($post) {
                if (empty($allowed_post_types) || in_array($post->post_type, $allowed_post_types, true)) {
                    return [
                        'id'       => $post->ID,
                        'type'     => 'post',
                        'sub_type' => $post->post_type,
                    ];
                }
            }

            // Check if it's a term
            $term = get_term($id);
            if ($term && !is_wp_error($term)) {
                if (empty($allowed_taxonomies) || in_array($term->taxonomy, $allowed_taxonomies, true)) {
                    return [
                        'id'       => $term->term_id,
                        'type'     => 'term',
                        'sub_type' => $term->taxonomy,
                    ];
                }
            }
            return null;
        }

        // Normalize URL/Slug
        $url = self::normalize_url($identifier);
        $path = self::get_path_from_url($url);

        // 2. Resolve via url_to_postid
        $post_id = url_to_postid($url);
        if ($post_id > 0) {
            $post = get_post($post_id);
            if ($post && (empty($allowed_post_types) || in_array($post->post_type, $allowed_post_types, true))) {
                return [
                    'id'       => $post->ID,
                    'type'     => 'post',
                    'sub_type' => $post->post_type,
                ];
            }
        }

        // 3. Resolve via get_page_by_path (handles nested pages/hierarchical post types)
        $post_types = empty($allowed_post_types) ? self::get_all_post_types() : $allowed_post_types;
        $post = get_page_by_path($path, OBJECT, $post_types);
        if ($post) {
            return [
                'id'       => $post->ID,
                'type'     => 'post',
                'sub_type' => $post->post_type,
            ];
        }

        // 4. Resolve via name/slug for non-hierarchical post types
        $slug = basename($path);
        if (!empty($slug)) {
            $posts = get_posts([
                'name'        => $slug,
                'post_type'   => $post_types,
                'post_status' => 'any',
                'numberposts' => 1,
            ]);
            if (!empty($posts)) {
                return [
                    'id'       => $posts[0]->ID,
                    'type'     => 'post',
                    'sub_type' => $posts[0]->post_type,
                ];
            }
        }

        // 5. Resolve Taxonomy Terms
        $taxonomies = empty($allowed_taxonomies) ? self::get_all_taxonomies() : $allowed_taxonomies;
        
        // Try exact match on path (e.g. tag/my-tag) or slug (my-tag)
        $slug_candidate = basename($path);
        if (!empty($slug_candidate)) {
            foreach ($taxonomies as $taxonomy) {
                // Try by slug
                $term = get_term_by('slug', $slug_candidate, $taxonomy);
                if ($term && !is_wp_error($term)) {
                    return [
                        'id'       => $term->term_id,
                        'type'     => 'term',
                        'sub_type' => $taxonomy,
                    ];
                }
                
                // Try by name (case-insensitive)
                $term = get_term_by('name', $slug_candidate, $taxonomy);
                if ($term && !is_wp_error($term)) {
                    return [
                        'id'       => $term->term_id,
                        'type'     => 'term',
                        'sub_type' => $taxonomy,
                    ];
                }
            }
        }

        return null;
    }

    /**
     * Normalize URL (prepending domain if relative, stripping query string & trailing slashes).
     */
    public static function normalize_url(string $url): string {
        // Strip query string
        if (($pos = strpos($url, '?')) !== false) {
            $url = substr($url, 0, $pos);
        }

        // Strip hash fragment
        if (($pos = strpos($url, '#')) !== false) {
            $url = substr($url, 0, $pos);
        }

        $url = trim($url, " \t\n\r\0\x0B/");

        if (empty($url)) {
            return home_url();
        }

        // Check if relative
        if (strpos($url, 'http://') !== 0 && strpos($url, 'https://') !== 0) {
            // Prepend home URL
            $url = home_url('/' . $url);
        }

        return esc_url_raw($url);
    }

    /**
     * Extract path relative to WP home directory from normalized URL.
     */
    public static function get_path_from_url(string $url): string {
        $home_path = wp_parse_url(home_url(), PHP_URL_PATH) ?: '';
        $home_path = trim($home_path, '/');

        $url_path = wp_parse_url($url, PHP_URL_PATH) ?: '';
        $url_path = trim($url_path, '/');

        if (!empty($home_path) && strpos($url_path, $home_path) === 0) {
            $url_path = substr($url_path, strlen($home_path));
        }

        return trim($url_path, '/');
    }

    /**
     * Get all public post types.
     */
    public static function get_all_post_types(): array {
        return array_values(get_post_types(['public' => true]));
    }

    /**
     * Get all public taxonomies.
     */
    public static function get_all_taxonomies(): array {
        return array_values(get_taxonomies(['public' => true]));
    }
}
