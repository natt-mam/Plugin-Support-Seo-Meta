<?php
defined('ABSPATH') || exit;

// Retrieve all history
$history = \SEOMetaImporterPro\Includes\Database::get_history(100, 0); // Limit to last 100
?>
<div class="smip-card">
    <div class="smip-card-header" style="margin-bottom: 20px; align-items: center;">
        <div>
            <h2><?php _e('Import History & Rollbacks', 'seo-meta-importer-pro'); ?></h2>
            <p class="description"><?php _e('Review your past import executions and undo/rollback updates if needed. Pre-import backup snapshots are automatically created before editing any database values.', 'seo-meta-importer-pro'); ?></p>
        </div>
        <div>
            <!-- Download History CSV button -->
            <a href="<?php echo esc_url(add_query_arg(['smip_download_history' => '1', 'security' => wp_create_nonce('smip_admin_nonce')], admin_url('admin-ajax.php'))); ?>" class="smip-btn smip-btn-secondary" id="smip-btn-download-history">
                <span class="dashicons dashicons-download"></span> <?php _e('Download History Log CSV', 'seo-meta-importer-pro'); ?>
            </a>
        </div>
    </div>

    <div class="smip-card-body">
        <?php if (empty($history)) : ?>
            <div class="smip-empty-state">
                <span class="dashicons dashicons-info"></span>
                <p><?php _e('No import history records found.', 'seo-meta-importer-pro'); ?></p>
            </div>
        <?php else : ?>
            <table class="wp-list-table widefat striped table-view-list">
                <thead>
                    <tr>
                        <th><?php _e('ID', 'seo-meta-importer-pro'); ?></th>
                        <th><?php _e('Date / Time', 'seo-meta-importer-pro'); ?></th>
                        <th><?php _e('User', 'seo-meta-importer-pro'); ?></th>
                        <th><?php _e('Import Source', 'seo-meta-importer-pro'); ?></th>
                        <th><?php _e('Import Type', 'seo-meta-importer-pro'); ?></th>
                        <th><?php _e('Updated', 'seo-meta-importer-pro'); ?></th>
                        <th><?php _e('Failed', 'seo-meta-importer-pro'); ?></th>
                        <th><?php _e('SEO Plugin', 'seo-meta-importer-pro'); ?></th>
                        <th><?php _e('Execution', 'seo-meta-importer-pro'); ?></th>
                        <th><?php _e('Status', 'seo-meta-importer-pro'); ?></th>
                        <th><?php _e('Actions', 'seo-meta-importer-pro'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($history as $item) : 
                        $user = get_userdata($item['user_id']);
                        $username = $user ? $user->user_login : __('Unknown', 'seo-meta-importer-pro');
                        
                        // Check if rollback records exist for this import
                        global $wpdb;
                        $rollback_table = \SEOMetaImporterPro\Includes\Database::get_rollback_table_name();
                        $has_backup = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $rollback_table WHERE import_id = %d", $item['id'])) > 0;
                        ?>
                        <tr>
                            <td>#<?php echo esc_html($item['id']); ?></td>
                            <td><?php echo esc_html($item['date']); ?></td>
                            <td><?php echo esc_html($username); ?></td>
                            <td><code class="smip-code-path"><?php echo esc_html($item['filename']); ?></code></td>
                            <td><span class="smip-type-tag"><?php echo esc_html(str_replace('_', ' ', $item['import_type'])); ?></span></td>
                            <td><span class="smip-text-success"><strong><?php echo esc_html($item['rows_updated']); ?></strong></span></td>
                            <td><span class="<?php echo $item['rows_failed'] > 0 ? 'smip-text-danger' : ''; ?>"><?php echo esc_html($item['rows_failed']); ?></span></td>
                            <td><?php echo esc_html(ucwords($item['seo_plugin'])); ?></td>
                            <td><?php echo esc_html(number_format($item['execution_time'], 2)); ?>s</td>
                            <td>
                                <span class="smip-status-badge-inline smip-status-<?php echo esc_attr($item['status']); ?>">
                                    <?php echo esc_html(ucfirst($item['status'])); ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($item['status'] === 'completed' && $has_backup) : ?>
                                    <button class="smip-btn smip-btn-danger smip-btn-small smip-btn-rollback" data-id="<?php echo esc_attr($item['id']); ?>">
                                        <span class="dashicons dashicons-undo"></span> <?php _e('Rollback (Undo)', 'seo-meta-importer-pro'); ?>
                                    </button>
                                <?php elseif ($item['status'] === 'rolled_back') : ?>
                                    <span class="smip-text-muted"><?php _e('Rolled Back', 'seo-meta-importer-pro'); ?></span>
                                <?php else : ?>
                                    <span class="smip-text-muted">-</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>
