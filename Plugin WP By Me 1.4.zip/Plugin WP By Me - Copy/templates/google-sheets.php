<?php
defined('ABSPATH') || exit;

// Retrieve settings
$sheet_url = get_option('smip_google_sheet_url', '');
$api_key = get_option('smip_google_sheets_api_key', '');
$sync_interval = get_option('smip_auto_sync', 'manual');
?>
<div class="smip-card">
    <h2><?php _e('Google Sheets Integration', 'seo-meta-importer-pro'); ?></h2>
    <p class="description"><?php _e('Configure automated syncing or manual import of SEO metadata from a public Google Sheet. Make sure the Google Sheet is shared as "Anyone with the link can view".', 'seo-meta-importer-pro'); ?></p>
    
    <form id="smip-google-sheets-form" method="post" action="">
        <?php wp_nonce_field('smip_google_sheets_save', 'smip_sheets_nonce'); ?>
        
        <div class="smip-form-group">
            <label for="smip-google-sheet-url"><?php _e('Google Sheet URL', 'seo-meta-importer-pro'); ?></label>
            <input type="url" id="smip-google-sheet-url" name="smip_google_sheet_url" class="large-text" value="<?php echo esc_url($sheet_url); ?>" placeholder="https://docs.google.com/spreadsheets/d/SPREADSHEET_ID/edit?usp=sharing" required />
            <p class="description"><?php _e('Ensure the Google Sheet shares public read access. Specific tabs can be targeted by keeping the gid=ID parameter in the URL.', 'seo-meta-importer-pro'); ?></p>
        </div>

        <div class="smip-form-row-group" style="margin-top:20px;">
            <div class="smip-form-group" style="flex: 2;">
                <label for="smip-google-sheets-api-key"><?php _e('Google Sheets API Key (Optional)', 'seo-meta-importer-pro'); ?></label>
                <input type="text" id="smip-google-sheets-api-key" name="smip_google_sheets_api_key" class="regular-text" value="<?php echo esc_attr($api_key); ?>" placeholder="AIzaSy..." />
                <p class="description"><?php _e('Provide an API key if you want to connect via the official Google Sheets API instead of public CSV export URLs.', 'seo-meta-importer-pro'); ?></p>
            </div>
            
            <div class="smip-form-group" style="flex: 1;">
                <label for="smip-auto-sync"><?php _e('Automated Sync Interval', 'seo-meta-importer-pro'); ?></label>
                <select id="smip-auto-sync" name="smip_auto_sync">
                    <option value="manual" <?php selected($sync_interval, 'manual'); ?>><?php _e('Manual Sync Only', 'seo-meta-importer-pro'); ?></option>
                    <option value="hourly" <?php selected($sync_interval, 'hourly'); ?>><?php _e('Every Hour', 'seo-meta-importer-pro'); ?></option>
                    <option value="daily" <?php selected($sync_interval, 'daily'); ?>><?php _e('Daily', 'seo-meta-importer-pro'); ?></option>
                    <option value="weekly" <?php selected($sync_interval, 'weekly'); ?>><?php _e('Weekly', 'seo-meta-importer-pro'); ?></option>
                </select>
                <p class="description"><?php _e('Uses WordPress Cron tasks to pull metadata changes in the background.', 'seo-meta-importer-pro'); ?></p>
            </div>
        </div>

        <div style="margin-top: 30px;">
            <button type="submit" class="smip-btn smip-btn-primary" name="smip_save_sheets_settings">
                <?php _e('Save Integration Settings', 'seo-meta-importer-pro'); ?>
            </button>
            <button type="button" class="smip-btn smip-btn-secondary" id="smip-btn-sync-sheets-now" <?php echo empty($sheet_url) ? 'disabled' : ''; ?>>
                <span class="dashicons dashicons-update"></span> <?php _e('Import & Sync Now', 'seo-meta-importer-pro'); ?>
            </button>
        </div>
    </form>
</div>
