<?php
defined('ABSPATH') || exit;

$post_types = \SEOMetaImporterPro\Includes\Helper::get_all_post_types();
$taxonomies = \SEOMetaImporterPro\Includes\Helper::get_all_taxonomies();
$active_seo = \SEOMetaImporterPro\SEO\SEO_Bridge::detect_active_plugins();
?>
<div class="smip-card">
    <div class="smip-wizard">
        <!-- Wizard Navigation Headers -->
        <ul class="smip-wizard-steps">
            <li class="smip-step active" data-step="1">
                <span class="step-num">1</span>
                <span class="step-lbl"><?php _e('Upload CSV', 'seo-meta-importer-pro'); ?></span>
            </li>
            <li class="smip-step" data-step="2">
                <span class="step-num">2</span>
                <span class="step-lbl"><?php _e('Map Columns', 'seo-meta-importer-pro'); ?></span>
            </li>
            <li class="smip-step" data-step="3">
                <span class="step-num">3</span>
                <span class="step-lbl"><?php _e('Configure & Validate', 'seo-meta-importer-pro'); ?></span>
            </li>
            <li class="smip-step" data-step="4">
                <span class="step-num">4</span>
                <span class="step-lbl"><?php _e('Preview & Confirm', 'seo-meta-importer-pro'); ?></span>
            </li>
            <li class="smip-step" data-step="5">
                <span class="step-num">5</span>
                <span class="step-lbl"><?php _e('Importing', 'seo-meta-importer-pro'); ?></span>
            </li>
        </ul>

        <!-- STEP 1: Upload CSV -->
        <div class="smip-wizard-pane active" data-pane="1">
            <div class="smip-dropzone-container">
                <div class="smip-dropzone" id="smip-csv-dropzone">
                    <span class="dashicons dashicons-upload-alt smip-dropzone-icon"></span>
                    <h3><?php _e('Drag & Drop your CSV file here', 'seo-meta-importer-pro'); ?></h3>
                    <p><?php _e('or click to browse from your computer', 'seo-meta-importer-pro'); ?></p>
                    <input type="file" id="smip-csv-file-input" accept=".csv" style="display:none;" />
                </div>
                <div class="smip-upload-feedback" id="smip-upload-info" style="display:none;">
                    <span class="dashicons dashicons-yes-alt text-success"></span>
                    <span id="smip-filename-display"></span>
                </div>
            </div>

            <div class="smip-form-row-group">
                <div class="smip-form-group">
                    <label for="smip-csv-delimiter"><?php _e('CSV Delimiter', 'seo-meta-importer-pro'); ?></label>
                    <input type="text" id="smip-csv-delimiter" value="," maxlength="1" style="width:60px; text-align:center;" />
                </div>
                <div class="smip-form-group">
                    <label for="smip-csv-encoding"><?php _e('File Encoding', 'seo-meta-importer-pro'); ?></label>
                    <select id="smip-csv-encoding">
                        <option value="UTF-8">UTF-8</option>
                        <option value="Windows-1252">Windows-1252 (ANSI)</option>
                        <option value="ISO-8859-1">ISO-8859-1</option>
                    </select>
                </div>
            </div>

            <div class="smip-wizard-footer">
                <button type="button" class="smip-btn smip-btn-primary" id="smip-btn-to-step2" disabled>
                    <?php _e('Next: Map Columns', 'seo-meta-importer-pro'); ?> &rarr;
                </button>
            </div>
        </div>

        <!-- STEP 2: Map Columns -->
        <div class="smip-wizard-pane" data-pane="2">
            <h2><?php _e('Map CSV Columns to WordPress Fields', 'seo-meta-importer-pro'); ?></h2>
            <p class="description"><?php _e('Match your CSV headers to target SEO metadata fields. Leave unmapped if you want to skip that column.', 'seo-meta-importer-pro'); ?></p>
            
            <div class="smip-mapping-table-container">
                <table class="smip-mapping-table" id="smip-mapping-table">
                    <thead>
                        <tr>
                            <th><?php _e('CSV Column (Source)', 'seo-meta-importer-pro'); ?></th>
                            <th>&rarr;</th>
                            <th><?php _e('WordPress Field (Destination)', 'seo-meta-importer-pro'); ?></th>
                        </tr>
                    </thead>
                    <tbody id="smip-mapping-rows">
                        <!-- Mappings will be injected here dynamically by JS -->
                    </tbody>
                </table>
            </div>

            <div class="smip-wizard-footer">
                <button type="button" class="smip-btn smip-btn-secondary" id="smip-btn-back-to-step1">&larr; <?php _e('Back', 'seo-meta-importer-pro'); ?></button>
                <button type="button" class="smip-btn smip-btn-primary" id="smip-btn-to-step3"><?php _e('Next: Configure Filters', 'seo-meta-importer-pro'); ?> &rarr;</button>
            </div>
        </div>

        <!-- STEP 3: Configure Filters & Options -->
        <div class="smip-wizard-pane" data-pane="3">
            <h2><?php _e('Configure Import Filters & Validation Options', 'seo-meta-importer-pro'); ?></h2>
            
            <div class="smip-settings-grid">
                <!-- Post Type Filters -->
                <div class="smip-settings-column">
                    <h3><?php _e('Import to Post Types', 'seo-meta-importer-pro'); ?></h3>
                    <p class="description"><?php _e('Select which post types to update. Other types in the CSV will be skipped.', 'seo-meta-importer-pro'); ?></p>
                    <div class="smip-checkbox-list">
                        <?php foreach ($post_types as $pt) : ?>
                            <label>
                                <input type="checkbox" name="smip-import-post-types" value="<?php echo esc_attr($pt); ?>" checked />
                                <?php echo esc_html(ucfirst($pt)); ?>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Taxonomy Filters -->
                <div class="smip-settings-column">
                    <h3><?php _e('Import to Taxonomy Archives', 'seo-meta-importer-pro'); ?></h3>
                    <p class="description"><?php _e('Select which taxonomy archives to update.', 'seo-meta-importer-pro'); ?></p>
                    <div class="smip-checkbox-list">
                        <?php foreach ($taxonomies as $tax) : ?>
                            <label>
                                <input type="checkbox" name="smip-import-taxonomies" value="<?php echo esc_attr($tax); ?>" checked />
                                <?php echo esc_html(ucfirst($tax)); ?>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Engine Overrides -->
                <div class="smip-settings-column">
                    <h3><?php _e('Import Engine Options', 'seo-meta-importer-pro'); ?></h3>
                    <div class="smip-form-group">
                        <label for="smip-import-seo-plugin"><?php _e('Target SEO Plugin', 'seo-meta-importer-pro'); ?></label>
                        <select id="smip-import-seo-plugin">
                            <option value="auto"><?php _e('Auto-Detect Active Plugin', 'seo-meta-importer-pro'); ?></option>
                            <option value="yoast"><?php _e('Yoast SEO', 'seo-meta-importer-pro'); ?></option>
                            <option value="rankmath"><?php _e('Rank Math SEO', 'seo-meta-importer-pro'); ?></option>
                            <option value="aioseo"><?php _e('All in One SEO (AIOSEO)', 'seo-meta-importer-pro'); ?></option>
                            <option value="seopress"><?php _e('SEOPress', 'seo-meta-importer-pro'); ?></option>
                            <option value="slimseo"><?php _e('Slim SEO', 'seo-meta-importer-pro'); ?></option>
                            <option value="tsf"><?php _e('The SEO Framework', 'seo-meta-importer-pro'); ?></option>
                            <option value="custom"><?php _e('Custom Post Meta (Fallback)', 'seo-meta-importer-pro'); ?></option>
                        </select>
                    </div>

                    <div class="smip-form-group" style="margin-top:20px;">
                        <label>
                            <input type="checkbox" id="smip-import-dry-run" />
                            <strong><?php _e('Dry Run Mode (Simulate Only)', 'seo-meta-importer-pro'); ?></strong>
                        </label>
                        <p class="description"><?php _e('Check this to analyze and run the entire import without writing any changes to the database. Generates a report.', 'seo-meta-importer-pro'); ?></p>
                    </div>
                </div>
            </div>

            <div class="smip-wizard-footer" style="margin-top: 30px;">
                <button type="button" class="smip-btn smip-btn-secondary" id="smip-btn-back-to-step2">&larr; <?php _e('Back', 'seo-meta-importer-pro'); ?></button>
                <button type="button" class="smip-btn smip-btn-primary" id="smip-btn-to-step4"><?php _e('Validate & Preview', 'seo-meta-importer-pro'); ?> &rarr;</button>
            </div>
        </div>

        <!-- STEP 4: Preview & Confirm -->
        <div class="smip-wizard-pane" data-pane="4">
            <h2><?php _e('Pre-Import Analysis & Preview', 'seo-meta-importer-pro'); ?></h2>
            
            <!-- Analysis Statistics Widgets -->
            <div class="smip-preview-stats">
                <div class="smip-preview-stat-card">
                    <span class="smip-stat-num" id="smip-stat-total">0</span>
                    <span class="smip-stat-lbl"><?php _e('Total CSV Rows', 'seo-meta-importer-pro'); ?></span>
                </div>
                <div class="smip-preview-stat-card">
                    <span class="smip-stat-num smip-text-success" id="smip-stat-matched">0</span>
                    <span class="smip-stat-lbl"><?php _e('Matched Objects', 'seo-meta-importer-pro'); ?></span>
                </div>
                <div class="smip-preview-stat-card">
                    <span class="smip-stat-num smip-text-danger" id="smip-stat-notfound">0</span>
                    <span class="smip-stat-lbl"><?php _e('Not Found', 'seo-meta-importer-pro'); ?></span>
                </div>
                <div class="smip-preview-stat-card">
                    <span class="smip-stat-num smip-text-warning" id="smip-stat-duplicates">0</span>
                    <span class="smip-stat-lbl"><?php _e('Duplicate URLs', 'seo-meta-importer-pro'); ?></span>
                </div>
            </div>

            <!-- Validation Warnings Logs -->
            <div class="smip-warning-logs-container" id="smip-warnings-container" style="display:none;">
                <h3><?php _e('Validation Warnings', 'seo-meta-importer-pro'); ?></h3>
                <div class="smip-warning-logs" id="smip-warnings-list">
                    <!-- Warnings injected by JS -->
                </div>
            </div>

            <!-- Mapped Matches Preview Table -->
            <h3><?php _e('Sample Mapping Preview (First 10 Rows)', 'seo-meta-importer-pro'); ?></h3>
            <div class="smip-mapping-table-container">
                <table class="wp-list-table widefat striped" id="smip-preview-table">
                    <thead>
                        <tr>
                            <th><?php _e('Row', 'seo-meta-importer-pro'); ?></th>
                            <th><?php _e('Identifier', 'seo-meta-importer-pro'); ?></th>
                            <th><?php _e('Status', 'seo-meta-importer-pro'); ?></th>
                            <th><?php _e('Resolved Title (WordPress)', 'seo-meta-importer-pro'); ?></th>
                            <th><?php _e('Meta Updates Preview', 'seo-meta-importer-pro'); ?></th>
                        </tr>
                    </thead>
                    <tbody id="smip-preview-rows">
                        <!-- Preview rows injected by JS -->
                    </tbody>
                </table>
            </div>

            <div class="smip-wizard-footer" style="margin-top: 30px;">
                <button type="button" class="smip-btn smip-btn-secondary" id="smip-btn-back-to-step3">&larr; <?php _e('Back', 'seo-meta-importer-pro'); ?></button>
                <button type="button" class="smip-btn smip-btn-primary" id="smip-btn-confirm-import"><?php _e('Confirm & Start Import', 'seo-meta-importer-pro'); ?> &rarr;</button>
            </div>
        </div>

        <!-- STEP 5: Import Progress -->
        <div class="smip-wizard-pane" data-pane="5">
            <h2 id="smip-progress-header"><?php _e('Importing Metadata...', 'seo-meta-importer-pro'); ?></h2>
            
            <div class="smip-progress-container">
                <div class="smip-progress-bar">
                    <div class="smip-progress-fill" id="smip-import-progress-fill" style="width: 0%;"></div>
                </div>
                <div class="smip-progress-stats">
                    <span id="smip-progress-percent">0%</span>
                    <span id="smip-progress-fraction">0 / 0 <?php _e('rows processed', 'seo-meta-importer-pro'); ?></span>
                </div>
            </div>

            <div class="smip-import-console-container">
                <h3><?php _e('Execution Console Logs', 'seo-meta-importer-pro'); ?></h3>
                <pre class="smip-import-console" id="smip-import-console-logs"></pre>
            </div>

            <div class="smip-wizard-footer">
                <button type="button" class="smip-btn smip-btn-secondary" id="smip-btn-pause-import"><?php _e('Pause', 'seo-meta-importer-pro'); ?></button>
                <button type="button" class="smip-btn smip-btn-secondary" id="smip-btn-resume-import" style="display:none;"><?php _e('Resume', 'seo-meta-importer-pro'); ?></button>
                <button type="button" class="smip-btn smip-btn-danger" id="smip-btn-cancel-import"><?php _e('Cancel / Halt', 'seo-meta-importer-pro'); ?></button>
                <button type="button" class="smip-btn smip-btn-success" id="smip-btn-finish-import" style="display:none;"><?php _e('Finish & View History', 'seo-meta-importer-pro'); ?></button>
            </div>
        </div>
    </div>
</div>
