<?php
defined('ABSPATH') || exit;

// Fetch some history items
$recent_history = \SEOMetaImporterPro\Includes\Database::get_history(5, 0);
$logger = new \SEOMetaImporterPro\Logger\Logger();
$recent_logs = $logger->get_recent_entries(10);
?>
<div class="smip-dashboard-grid">
    <!-- Stat Cards -->
    <div class="smip-card smip-stat-card">
        <div class="smip-stat-icon smip-color-primary">
            <span class="dashicons dashicons-cloud-upload"></span>
        </div>
        <div class="smip-stat-details">
            <h3><?php _e('Total Imports', 'seo-meta-importer-pro'); ?></h3>
            <div class="smip-stat-value"><?php echo esc_html($total_imports); ?></div>
            <p><?php _e('Lifetime import actions run', 'seo-meta-importer-pro'); ?></p>
        </div>
    </div>

    <div class="smip-card smip-stat-card">
        <div class="smip-stat-icon smip-color-success">
            <span class="dashicons dashicons-yes-alt"></span>
        </div>
        <div class="smip-stat-details">
            <h3><?php _e('Last Import Updates', 'seo-meta-importer-pro'); ?></h3>
            <div class="smip-stat-value">
                <?php echo $last_import ? esc_html($last_import['rows_updated']) : '0'; ?>
            </div>
            <p>
                <?php 
                if ($last_import) {
                    printf(__('Rows updated on %s', 'seo-meta-importer-pro'), esc_html($last_import['date']));
                } else {
                    _e('No imports run yet', 'seo-meta-importer-pro');
                }
                ?>
            </p>
        </div>
    </div>

    <div class="smip-card smip-stat-card">
        <div class="smip-stat-icon smip-color-warning">
            <span class="dashicons dashicons-warning"></span>
        </div>
        <div class="smip-stat-details">
            <h3><?php _e('Last Import Failed', 'seo-meta-importer-pro'); ?></h3>
            <div class="smip-stat-value text-danger">
                <?php echo $last_import ? esc_html($last_import['rows_failed']) : '0'; ?>
            </div>
            <p><?php _e('Skipped or broken rows in last run', 'seo-meta-importer-pro'); ?></p>
        </div>
    </div>
</div>

<div class="smip-dashboard-sections">
    <!-- Recent History -->
    <div class="smip-card smip-history-card">
        <div class="smip-card-header">
            <h2><?php _e('Recent Import History', 'seo-meta-importer-pro'); ?></h2>
            <a href="#history" class="smip-btn smip-btn-text smip-trigger-tab-link" data-target="history"><?php _e('View All', 'seo-meta-importer-pro'); ?> &rarr;</a>
        </div>
        <div class="smip-card-body">
            <?php if (empty($recent_history)) : ?>
                <div class="smip-empty-state">
                    <span class="dashicons dashicons-info"></span>
                    <p><?php _e('No history entries found. Import your first file to get started.', 'seo-meta-importer-pro'); ?></p>
                </div>
            <?php else : ?>
                <table class="wp-list-table widefat striped table-view-list">
                    <thead>
                        <tr>
                            <th><?php _e('ID', 'seo-meta-importer-pro'); ?></th>
                            <th><?php _e('Date', 'seo-meta-importer-pro'); ?></th>
                            <th><?php _e('Source', 'seo-meta-importer-pro'); ?></th>
                            <th><?php _e('Updated', 'seo-meta-importer-pro'); ?></th>
                            <th><?php _e('Failed', 'seo-meta-importer-pro'); ?></th>
                            <th><?php _e('Status', 'seo-meta-importer-pro'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recent_history as $item) : ?>
                            <tr>
                                <td>#<?php echo esc_html($item['id']); ?></td>
                                <td><?php echo esc_html($item['date']); ?></td>
                                <td><strong><?php echo esc_html($item['filename']); ?></strong></td>
                                <td><span class="smip-text-success"><?php echo esc_html($item['rows_updated']); ?></span></td>
                                <td><span class="<?php echo $item['rows_failed'] > 0 ? 'smip-text-danger' : ''; ?>"><?php echo esc_html($item['rows_failed']); ?></span></td>
                                <td>
                                    <span class="smip-status-badge-inline smip-status-<?php echo esc_attr($item['status']); ?>">
                                        <?php echo esc_html(ucfirst($item['status'])); ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="smip-card smip-actions-card">
        <h2><?php _e('Quick Tasks', 'seo-meta-importer-pro'); ?></h2>
        <div class="smip-action-buttons">
            <button class="smip-btn smip-btn-primary smip-trigger-tab-link" data-target="import-csv">
                <span class="dashicons dashicons-upload"></span> <?php _e('Import CSV File', 'seo-meta-importer-pro'); ?>
            </button>
            <button class="smip-btn smip-btn-secondary smip-trigger-tab-link" data-target="google-sheets">
                <span class="dashicons dashicons-cloud"></span> <?php _e('Sync Google Sheet', 'seo-meta-importer-pro'); ?>
            </button>
            <button class="smip-btn smip-btn-secondary smip-trigger-tab-link" data-target="export">
                <span class="dashicons dashicons-download"></span> <?php _e('Export SEO Data', 'seo-meta-importer-pro'); ?>
            </button>
        </div>
    </div>
</div>
