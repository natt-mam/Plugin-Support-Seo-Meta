<?php
defined('ABSPATH') || exit;

// Fetch current active SEO plugin and details for headers
$active_plugins = \SEOMetaImporterPro\SEO\SEO_Bridge::detect_active_plugins();
$default_seo = get_option('smip_default_seo_plugin', 'auto');
$bridge = \SEOMetaImporterPro\SEO\SEO_Bridge::get_bridge_instance($default_seo);

$history_summary = \SEOMetaImporterPro\Includes\Database::get_history(1, 0);
$last_import = !empty($history_summary) ? $history_summary[0] : null;
$total_imports = \SEOMetaImporterPro\Includes\Database::get_history_count();
$moveahead_logo_url = plugins_url('assets/images/moveahead-logo.svg', dirname(__DIR__) . '/seo-meta-importer-pro.php');
?>
<div class="wrap smip-admin-wrapper">
    <!-- Header Area -->
    <header class="smip-header">
        <div class="smip-brand">
            <img class="smip-brand-logo" src="<?php echo esc_url($moveahead_logo_url); ?>" alt="<?php esc_attr_e('MoveAhead media', 'seo-meta-importer-pro'); ?>" />
            <div class="smip-brand-text">
                <h1><?php _e('SEO Meta Importer Pro', 'seo-meta-importer-pro'); ?></h1>
                <p class="smip-subtitle"><?php _e('Professional Bulk Metadata Import & Export', 'seo-meta-importer-pro'); ?></p>
            </div>
        </div>
        <div class="smip-status-badge">
            <span class="smip-badge-dot"></span>
            <span class="smip-status-text">
                <?php 
                if (!empty($active_plugins)) {
                    printf(__('Active SEO: %s', 'seo-meta-importer-pro'), implode(', ', $active_plugins));
                } else {
                    _e('Active SEO: Custom Meta (Fallback)', 'seo-meta-importer-pro');
                }
                ?>
            </span>
        </div>
    </header>

    <!-- Tab Navigation -->
    <nav class="smip-nav-tabs" aria-label="<?php esc_attr_e('Plugin navigation', 'seo-meta-importer-pro'); ?>">
        <a href="#dashboard" class="smip-nav-tab active" data-tab="dashboard">
            <span class="dashicons dashicons-dashboard"></span> <?php _e('Dashboard', 'seo-meta-importer-pro'); ?>
        </a>
        <a href="#import-csv" class="smip-nav-tab" data-tab="import-csv">
            <span class="dashicons dashicons-upload"></span> <?php _e('Import CSV', 'seo-meta-importer-pro'); ?>
        </a>
        <a href="#google-sheets" class="smip-nav-tab" data-tab="google-sheets">
            <span class="dashicons dashicons-cloud"></span> <?php _e('Google Sheets', 'seo-meta-importer-pro'); ?>
        </a>
        <a href="#export" class="smip-nav-tab" data-tab="export">
            <span class="dashicons dashicons-download"></span> <?php _e('Export', 'seo-meta-importer-pro'); ?>
        </a>
        <a href="#history" class="smip-nav-tab" data-tab="history">
            <span class="dashicons dashicons-backup"></span> <?php _e('History & Rollback', 'seo-meta-importer-pro'); ?>
        </a>
        <a href="#settings" class="smip-nav-tab" data-tab="settings">
            <span class="dashicons dashicons-admin-generic"></span> <?php _e('Settings', 'seo-meta-importer-pro'); ?>
        </a>
        <a href="#logs" class="smip-nav-tab" data-tab="logs">
            <span class="dashicons dashicons-list-view"></span> <?php _e('Logs', 'seo-meta-importer-pro'); ?>
        </a>
        <a href="#manual" class="smip-nav-tab" data-tab="manual">
            <span class="dashicons dashicons-book"></span> <?php _e('User Guide', 'seo-meta-importer-pro'); ?>
        </a>
    </nav>

    <!-- Content Sections -->
    <main class="smip-tab-content">
        <!-- Dashboard Tab -->
        <section id="tab-dashboard" class="smip-tab-pane active" aria-labelledby="dashboard">
            <?php require_once __DIR__ . '/dashboard.php'; ?>
        </section>

        <!-- Import CSV Tab -->
        <section id="tab-import-csv" class="smip-tab-pane" aria-labelledby="import-csv">
            <?php require_once __DIR__ . '/import-csv.php'; ?>
        </section>

        <!-- Google Sheets Tab -->
        <section id="tab-google-sheets" class="smip-tab-pane" aria-labelledby="google-sheets">
            <?php require_once __DIR__ . '/google-sheets.php'; ?>
        </section>

        <!-- Export Tab -->
        <section id="tab-export" class="smip-tab-pane" aria-labelledby="export">
            <?php require_once __DIR__ . '/export.php'; ?>
        </section>

        <!-- History Tab -->
        <section id="tab-history" class="smip-tab-pane" aria-labelledby="history">
            <?php require_once __DIR__ . '/history.php'; ?>
        </section>

        <!-- Settings Tab -->
        <section id="tab-settings" class="smip-tab-pane" aria-labelledby="settings">
            <?php require_once __DIR__ . '/settings.php'; ?>
        </section>

        <!-- Logs Tab -->
        <section id="tab-logs" class="smip-tab-pane" aria-labelledby="logs">
            <?php require_once __DIR__ . '/logs.php'; ?>
        </section>

        <!-- Manual Tab -->
        <section id="tab-manual" class="smip-tab-pane" aria-labelledby="manual">
            <?php require_once __DIR__ . '/manual.php'; ?>
        </section>
    </main>
</div>
