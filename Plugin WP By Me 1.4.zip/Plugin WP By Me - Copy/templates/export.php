<?php
defined('ABSPATH') || exit;

$post_types = \SEOMetaImporterPro\Includes\Helper::get_all_post_types();
$taxonomies = \SEOMetaImporterPro\Includes\Helper::get_all_taxonomies();
?>
<div class="smip-card">
    <h2><?php _e('Export SEO Metadata', 'seo-meta-importer-pro'); ?></h2>
    <p class="description"><?php _e('Generate and download a CSV file containing the existing SEO metadata of your pages, posts, custom post types, categories, or tags.', 'seo-meta-importer-pro'); ?></p>
    
    <form id="smip-export-form" method="post" action="">
        <div class="smip-settings-grid">
            <!-- Post Types to Export -->
            <div class="smip-settings-column">
                <h3><?php _e('Export Post Types', 'seo-meta-importer-pro'); ?></h3>
                <div class="smip-checkbox-list">
                    <?php foreach ($post_types as $pt) : ?>
                        <label>
                            <input type="checkbox" name="smip-export-post-types" value="<?php echo esc_attr($pt); ?>" checked />
                            <?php echo esc_html(ucfirst($pt)); ?>
                        </label>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Taxonomies to Export -->
            <div class="smip-settings-column">
                <h3><?php _e('Export Taxonomies', 'seo-meta-importer-pro'); ?></h3>
                <div class="smip-checkbox-list">
                    <?php foreach ($taxonomies as $tax) : ?>
                        <label>
                            <input type="checkbox" name="smip-export-taxonomies" value="<?php echo esc_attr($tax); ?>" checked />
                            <?php echo esc_html(ucfirst($tax)); ?>
                        </label>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Options -->
            <div class="smip-settings-column">
                <h3><?php _e('Export Engine Options', 'seo-meta-importer-pro'); ?></h3>
                
                <div class="smip-form-group">
                    <label for="smip-export-seo-plugin"><?php _e('Source SEO Plugin', 'seo-meta-importer-pro'); ?></label>
                    <select id="smip-export-seo-plugin">
                        <option value="auto"><?php _e('Auto-Detect Active Plugin', 'seo-meta-importer-pro'); ?></option>
                        <option value="yoast"><?php _e('Yoast SEO', 'seo-meta-importer-pro'); ?></option>
                        <option value="rankmath"><?php _e('Rank Math SEO', 'seo-meta-importer-pro'); ?></option>
                        <option value="aioseo"><?php _e('All in One SEO (AIOSEO)', 'seo-meta-importer-pro'); ?></option>
                        <option value="seopress"><?php _e('SEOPress', 'seo-meta-importer-pro'); ?></option>
                        <option value="slimseo"><?php _e('Slim SEO', 'seo-meta-importer-pro'); ?></option>
                        <option value="tsf"><?php _e('The SEO Framework', 'seo-meta-importer-pro'); ?></option>
                        <option value="custom"><?php _e('Custom Post Meta (Fallback)', 'seo-meta-importer-pro'); ?></option>
                    </select>
                </div>
            </div>
        </div>

        <div style="margin-top: 30px;" class="smip-export-actions">
            <button type="button" class="smip-btn smip-btn-primary" id="smip-btn-start-export">
                <span class="dashicons dashicons-download"></span> <?php _e('Generate Export File', 'seo-meta-importer-pro'); ?>
            </button>
            <span class="smip-spinner" id="smip-export-spinner" style="display:none; vertical-align:middle; margin-left:10px;"></span>
        </div>

        <div class="smip-export-download-box" id="smip-export-download-box" style="display:none; margin-top:20px;">
            <div class="smip-alert smip-alert-success">
                <span class="dashicons dashicons-yes-alt"></span>
                <p>
                    <strong><?php _e('Export generated successfully!', 'seo-meta-importer-pro'); ?></strong><br />
                    <a href="#" id="smip-export-download-link" class="smip-btn smip-btn-primary" style="margin-top:10px;" download><?php _e('Download Export CSV', 'seo-meta-importer-pro'); ?></a>
                </p>
            </div>
        </div>
    </form>
</div>
