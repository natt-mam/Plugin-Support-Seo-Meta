<?php
defined('ABSPATH') || exit;

// Retrieve settings
$batch_size = get_option('smip_batch_size', 100);
$max_rows = get_option('smip_max_rows', 100000);
$delimiter = get_option('smip_csv_delimiter', ',');
$encoding = get_option('smip_encoding', 'UTF-8');
$default_seo = get_option('smip_default_seo_plugin', 'auto');
$timezone = get_option('smip_timezone', 'UTC');
$debug_mode = get_option('smip_debug_mode', 'no');
?>
<div class="smip-card">
    <h2><?php _e('Settings & Configurations', 'seo-meta-importer-pro'); ?></h2>
    
    <form id="smip-settings-form" method="post" action="">
        <?php wp_nonce_field('smip_settings_save', 'smip_settings_nonce'); ?>
        
        <table class="form-table" role="presentation">
            <tbody>
                <!-- Batch Size -->
                <tr>
                    <th scope="row"><label for="smip_batch_size"><?php _e('Import Batch Size', 'seo-meta-importer-pro'); ?></label></th>
                    <td>
                        <input type="number" id="smip_batch_size" name="smip_batch_size" value="<?php echo esc_attr($batch_size); ?>" min="10" max="1000" class="small-text" required />
                        <p class="description"><?php _e('Number of rows processed per AJAX request. Reduce this if you experience server timeouts.', 'seo-meta-importer-pro'); ?></p>
                    </td>
                </tr>

                <!-- Max Rows -->
                <tr>
                    <th scope="row"><label for="smip_max_rows"><?php _e('Maximum Row Limit', 'seo-meta-importer-pro'); ?></label></th>
                    <td>
                        <input type="number" id="smip_max_rows" name="smip_max_rows" value="<?php echo esc_attr($max_rows); ?>" min="100" max="500000" class="regular-text" required />
                        <p class="description"><?php _e('Maximum number of rows allowed in a single import file. Helps prevent server overloading.', 'seo-meta-importer-pro'); ?></p>
                    </td>
                </tr>

                <!-- Delimiter -->
                <tr>
                    <th scope="row"><label for="smip_csv_delimiter"><?php _e('Default CSV Delimiter', 'seo-meta-importer-pro'); ?></label></th>
                    <td>
                        <input type="text" id="smip_csv_delimiter" name="smip_csv_delimiter" value="<?php echo esc_attr($delimiter); ?>" maxlength="1" class="small-text" style="text-align:center;" required />
                        <p class="description"><?php _e('Default character used to separate fields in CSV files (typically a comma or semicolon).', 'seo-meta-importer-pro'); ?></p>
                    </td>
                </tr>

                <!-- Encoding -->
                <tr>
                    <th scope="row"><label for="smip_encoding"><?php _e('Default File Encoding', 'seo-meta-importer-pro'); ?></label></th>
                    <td>
                        <select id="smip_encoding" name="smip_encoding">
                            <option value="UTF-8" <?php selected($encoding, 'UTF-8'); ?>>UTF-8</option>
                            <option value="Windows-1252" <?php selected($encoding, 'Windows-1252'); ?>>Windows-1252 (ANSI / Excel)</option>
                            <option value="ISO-8859-1" <?php selected($encoding, 'ISO-8859-1'); ?>>ISO-8859-1</option>
                        </select>
                        <p class="description"><?php _e('Select character set for parsing CSV contents if they contain accents or special characters.', 'seo-meta-importer-pro'); ?></p>
                    </td>
                </tr>

                <!-- Default SEO Plugin -->
                <tr>
                    <th scope="row"><label for="smip_default_seo_plugin"><?php _e('Default SEO Plugin target', 'seo-meta-importer-pro'); ?></label></th>
                    <td>
                        <select id="smip_default_seo_plugin" name="smip_default_seo_plugin">
                            <option value="auto" <?php selected($default_seo, 'auto'); ?>><?php _e('Auto-Detect Active Plugin', 'seo-meta-importer-pro'); ?></option>
                            <option value="yoast" <?php selected($default_seo, 'yoast'); ?>><?php _e('Yoast SEO', 'seo-meta-importer-pro'); ?></option>
                            <option value="rankmath" <?php selected($default_seo, 'rankmath'); ?>><?php _e('Rank Math SEO', 'seo-meta-importer-pro'); ?></option>
                            <option value="aioseo" <?php selected($default_seo, 'aioseo'); ?>><?php _e('All in One SEO (AIOSEO)', 'seo-meta-importer-pro'); ?></option>
                            <option value="seopress" <?php selected($default_seo, 'seopress'); ?>><?php _e('SEOPress', 'seo-meta-importer-pro'); ?></option>
                            <option value="slimseo" <?php selected($default_seo, 'slimseo'); ?>><?php _e('Slim SEO', 'seo-meta-importer-pro'); ?></option>
                            <option value="tsf" <?php selected($default_seo, 'tsf'); ?>><?php _e('The SEO Framework', 'seo-meta-importer-pro'); ?></option>
                            <option value="custom" <?php selected($default_seo, 'custom'); ?>><?php _e('Custom Post Meta (Fallback)', 'seo-meta-importer-pro'); ?></option>
                        </select>
                        <p class="description"><?php _e('Select which SEO plugin should be updated by default.', 'seo-meta-importer-pro'); ?></p>
                    </td>
                </tr>

                <!-- Timezone -->
                <tr>
                    <th scope="row"><label for="smip_timezone"><?php _e('Cron Sync Timezone', 'seo-meta-importer-pro'); ?></label></th>
                    <td>
                        <input type="text" id="smip_timezone" name="smip_timezone" value="<?php echo esc_attr($timezone); ?>" class="regular-text" required />
                        <p class="description"><?php _e('Timezone used for scheduling automated sync operations (e.g. UTC, America/New_York).', 'seo-meta-importer-pro'); ?></p>
                    </td>
                </tr>

                <!-- Debug Mode -->
                <tr>
                    <th scope="row"><label for="smip_debug_mode"><?php _e('Debug logging mode', 'seo-meta-importer-pro'); ?></label></th>
                    <td>
                        <select id="smip_debug_mode" name="smip_debug_mode">
                            <option value="no" <?php selected($debug_mode, 'no'); ?>><?php _e('Disabled', 'seo-meta-importer-pro'); ?></option>
                            <option value="yes" <?php selected($debug_mode, 'yes'); ?>><?php _e('Enabled (Write verbose entries)', 'seo-meta-importer-pro'); ?></option>
                        </select>
                        <p class="description"><?php _e('Enable logging of detailed debug information in the log file.', 'seo-meta-importer-pro'); ?></p>
                    </td>
                </tr>
            </tbody>
        </table>

        <div style="margin-top: 30px;">
            <button type="submit" class="smip-btn smip-btn-primary" name="smip_save_settings">
                <?php _e('Save Settings Configurations', 'seo-meta-importer-pro'); ?>
            </button>
        </div>
    </form>
</div>
