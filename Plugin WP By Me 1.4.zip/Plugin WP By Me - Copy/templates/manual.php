<?php
defined('ABSPATH') || exit;

$manual_url = plugins_url('docs/SEO-Meta-Importer-Pro-User-Guide.docx', dirname(__DIR__) . '/seo-meta-importer-pro.php');
?>
<div class="smip-card">
    <div class="smip-card-header" style="align-items: center;">
        <div>
            <h2><?php esc_html_e('User Guide', 'seo-meta-importer-pro'); ?></h2>
            <p class="description"><?php esc_html_e('English instructions for uploading CSV files, mapping SEO fields, previewing changes, importing metadata, exporting data, and using rollback.', 'seo-meta-importer-pro'); ?></p>
        </div>
        <a href="<?php echo esc_url($manual_url); ?>" class="smip-btn smip-btn-primary" download>
            <span class="dashicons dashicons-media-document"></span>
            <?php esc_html_e('Download DOCX Guide', 'seo-meta-importer-pro'); ?>
        </a>
    </div>

    <div class="smip-manual-grid">
        <section class="smip-manual-section">
            <h3><?php esc_html_e('1. Prepare Your CSV File', 'seo-meta-importer-pro'); ?></h3>
            <ol>
                <li><?php esc_html_e('Create a CSV file with one row per page, post, product, or taxonomy archive.', 'seo-meta-importer-pro'); ?></li>
                <li><?php esc_html_e('Add an identifier column such as URL, relative URL, post ID, or slug.', 'seo-meta-importer-pro'); ?></li>
                <li><?php esc_html_e('Add SEO columns such as SEO Title, Meta Description, Focus Keyword, Canonical URL, Robots Index, Robots Follow, Open Graph Title, and Twitter Title.', 'seo-meta-importer-pro'); ?></li>
                <li><?php esc_html_e('Save the file as UTF-8 CSV when possible.', 'seo-meta-importer-pro'); ?></li>
            </ol>
        </section>

        <section class="smip-manual-section">
            <h3><?php esc_html_e('2. Upload the CSV', 'seo-meta-importer-pro'); ?></h3>
            <ol>
                <li><?php esc_html_e('Open SEO Meta Importer Pro in the WordPress admin area.', 'seo-meta-importer-pro'); ?></li>
                <li><?php esc_html_e('Go to the Import CSV tab.', 'seo-meta-importer-pro'); ?></li>
                <li><?php esc_html_e('Drag and drop your CSV file into the upload box, or click the box to browse.', 'seo-meta-importer-pro'); ?></li>
                <li><?php esc_html_e('Confirm the delimiter and file encoding, then click Next: Map Columns.', 'seo-meta-importer-pro'); ?></li>
            </ol>
        </section>

        <section class="smip-manual-section">
            <h3><?php esc_html_e('3. Map Columns', 'seo-meta-importer-pro'); ?></h3>
            <ol>
                <li><?php esc_html_e('Map your identifier column to Page Identifier (URL/Slug/ID).', 'seo-meta-importer-pro'); ?></li>
                <li><?php esc_html_e('Map each SEO column to the matching WordPress field.', 'seo-meta-importer-pro'); ?></li>
                <li><?php esc_html_e('Choose Custom Meta Key when you need to update a custom metadata key.', 'seo-meta-importer-pro'); ?></li>
                <li><?php esc_html_e('Leave columns unmapped when they should be skipped.', 'seo-meta-importer-pro'); ?></li>
            </ol>
        </section>

        <section class="smip-manual-section">
            <h3><?php esc_html_e('4. Configure and Preview', 'seo-meta-importer-pro'); ?></h3>
            <ol>
                <li><?php esc_html_e('Select the post types and taxonomies that should be included.', 'seo-meta-importer-pro'); ?></li>
                <li><?php esc_html_e('Choose the SEO plugin target, or keep Auto-Detect Active Plugin.', 'seo-meta-importer-pro'); ?></li>
                <li><?php esc_html_e('Enable Dry Run Mode when you want to test the import without changing database values.', 'seo-meta-importer-pro'); ?></li>
                <li><?php esc_html_e('Click Validate & Preview to review matched objects, warnings, duplicates, and skipped rows.', 'seo-meta-importer-pro'); ?></li>
            </ol>
        </section>

        <section class="smip-manual-section">
            <h3><?php esc_html_e('5. Run the Import', 'seo-meta-importer-pro'); ?></h3>
            <ol>
                <li><?php esc_html_e('Review the preview results carefully before continuing.', 'seo-meta-importer-pro'); ?></li>
                <li><?php esc_html_e('Click Confirm & Start Import to begin batch processing.', 'seo-meta-importer-pro'); ?></li>
                <li><?php esc_html_e('Use Pause, Resume, or Cancel if you need to control a long-running import.', 'seo-meta-importer-pro'); ?></li>
                <li><?php esc_html_e('When finished, open History & Rollback to confirm the result.', 'seo-meta-importer-pro'); ?></li>
            </ol>
        </section>

        <section class="smip-manual-section">
            <h3><?php esc_html_e('6. Export and Rollback', 'seo-meta-importer-pro'); ?></h3>
            <ol>
                <li><?php esc_html_e('Use the Export tab to download current SEO metadata as a CSV file.', 'seo-meta-importer-pro'); ?></li>
                <li><?php esc_html_e('Use History & Rollback to download history logs or undo a completed import.', 'seo-meta-importer-pro'); ?></li>
                <li><?php esc_html_e('Rollback restores backed-up metadata values from before the selected import.', 'seo-meta-importer-pro'); ?></li>
            </ol>
        </section>
    </div>
</div>
