<?php
defined('ABSPATH') || exit;

$logger = new \SEOMetaImporterPro\Logger\Logger();
$logs = $logger->get_recent_entries(200);
?>
<div class="smip-card">
    <div class="smip-card-header" style="margin-bottom: 20px; align-items: center;">
        <div>
            <h2><?php _e('Application Debug Logs', 'seo-meta-importer-pro'); ?></h2>
            <p class="description"><?php _e('View recent diagnostic information and warning trace lines. Valuable for checking background task status and sync problems.', 'seo-meta-importer-pro'); ?></p>
        </div>
        <div>
            <button type="button" class="smip-btn smip-btn-secondary" id="smip-btn-refresh-logs">
                <span class="dashicons dashicons-update"></span> <?php _e('Refresh Logs', 'seo-meta-importer-pro'); ?>
            </button>
            <button type="button" class="smip-btn smip-btn-danger" id="smip-btn-clear-logs">
                <span class="dashicons dashicons-trash"></span> <?php _e('Clear Log Entries', 'seo-meta-importer-pro'); ?>
            </button>
        </div>
    </div>

    <div class="smip-card-body">
        <div class="smip-log-console-container">
            <pre class="smip-log-console" id="smip-logs-view"><?php echo esc_html($logs); ?></pre>
        </div>
    </div>
</div>
