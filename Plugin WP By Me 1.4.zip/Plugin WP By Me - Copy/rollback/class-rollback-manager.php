<?php
namespace SEOMetaImporterPro\Rollback;

defined('ABSPATH') || exit;

class Rollback_Manager {
    /**
     * Rollback a specific import run.
     * 
     * @return int|\WP_Error Number of restored meta rows or WP_Error.
     */
    public static function rollback_import(int $import_id): int|\WP_Error {
        $history = \SEOMetaImporterPro\Includes\Database::get_history_item($import_id);
        if (!$history) {
            return new \WP_Error('invalid_import_id', __('Import history record not found.', 'seo-meta-importer-pro'));
        }

        if ($history['status'] === 'rolled_back') {
            return new \WP_Error('already_rolled_back', __('This import has already been rolled back.', 'seo-meta-importer-pro'));
        }

        $items = \SEOMetaImporterPro\Includes\Database::get_rollback_items($import_id);
        if (empty($items)) {
            // Nothing to rollback, but let's still update status
            \SEOMetaImporterPro\Includes\Database::update_history($import_id, ['status' => 'rolled_back']);
            return 0;
        }

        $restored_count = 0;

        foreach ($items as $item) {
            $object_id = intval($item['object_id']);
            $object_type = $item['object_type'];
            $meta_key = $item['meta_key'];
            $old_value = $item['old_value'];

            // Attempt to unserialize array/object values
            $unserialized = @unserialize($old_value);
            $restored_val = ($unserialized !== false || $old_value === 'b:0;') ? $unserialized : $old_value;

            // Perform restoration
            if ($object_type === 'term') {
                if ($restored_val === null || $restored_val === '') {
                    $deleted = delete_term_meta($object_id, $meta_key);
                    if ($deleted) $restored_count++;
                } else {
                    $updated = update_term_meta($object_id, $meta_key, $restored_val);
                    if ($updated !== false) $restored_count++;
                }
            } else {
                if ($restored_val === null || $restored_val === '') {
                    $deleted = delete_post_meta($object_id, $meta_key);
                    if ($deleted) $restored_count++;
                } else {
                    $updated = update_post_meta($object_id, $meta_key, $restored_val);
                    if ($updated !== false) $restored_count++;
                }
            }
        }

        // Clean up rollback database entries for this import to save space
        \SEOMetaImporterPro\Includes\Database::delete_rollback_items($import_id);

        // Update history status
        \SEOMetaImporterPro\Includes\Database::update_history($import_id, ['status' => 'rolled_back']);

        return $restored_count;
    }
}
