<?php
namespace SEOMetaImporterPro\SEO;

defined('ABSPATH') || exit;

abstract class SEO_Bridge {
    /**
     * Get unique name of the bridge.
     */
    abstract public function get_name(): string;

    /**
     * Get display label of the bridge.
     */
    abstract public function get_label(): string;

    /**
     * Get list of supported SEO fields and their descriptions.
     * Format: [ 'field_id' => 'Field Label' ]
     */
    abstract public function get_fields(): array;

    /**
     * Get meta value for a specific field.
     */
    abstract public function get_meta(int $object_id, string $object_type, string $field_key): string;

    /**
     * Update meta value for a specific field.
     */
    abstract public function update_meta(int $object_id, string $object_type, string $field_key, $value): bool;

    /**
     * Detect which SEO plugins are active.
     */
    public static function detect_active_plugins(): array {
        $active = [];

        if (defined('WPSEO_VERSION')) {
            $active['yoast'] = 'Yoast SEO';
        }
        if (class_exists('RankMath')) {
            $active['rankmath'] = 'Rank Math SEO';
        }
        if (defined('AIOSEO_VERSION')) {
            $active['aioseo'] = 'All in One SEO (AIOSEO)';
        }
        if (defined('SEOPRESS_VERSION')) {
            $active['seopress'] = 'SEOPress';
        }
        if (defined('SLIM_SEO_DIR') || class_exists('SlimSEO\Loader')) {
            $active['slimseo'] = 'Slim SEO';
        }
        if (defined('THE_SEO_FRAMEWORK_VERSION') || class_exists('The_SEO_Framework\Load')) {
            $active['tsf'] = 'The SEO Framework';
        }

        return $active;
    }

    /**
     * Get the selected SEO bridge instance.
     */
    public static function get_bridge_instance(string $bridge_name = ''): SEO_Bridge {
        if (empty($bridge_name) || $bridge_name === 'auto') {
            $active = self::detect_active_plugins();
            if (!empty($active)) {
                $bridge_name = array_key_first($active);
            } else {
                $bridge_name = 'custom';
            }
        }

        switch ($bridge_name) {
            case 'yoast':
                return new Yoast_Bridge();
            case 'rankmath':
                return new Rankmath_Bridge();
            case 'aioseo':
                return new Aioseo_Bridge();
            case 'seopress':
                return new Seopress_Bridge();
            case 'slimseo':
                return new Slimseo_Bridge();
            case 'tsf':
                return new Tsf_Bridge();
            case 'custom':
            default:
                return new Custom_Bridge();
        }
    }
}
