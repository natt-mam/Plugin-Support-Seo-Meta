<?php
namespace SEOMetaImporterPro\SEO;

defined('ABSPATH') || exit;

class Seopress_Bridge extends SEO_Bridge {
    private array $field_map = [
        'title'               => '_seopress_titles_title',
        'description'         => '_seopress_titles_desc',
        'focus_keyword'       => '_seopress_analysis_target_kw',
        'canonical'           => '_seopress_robots_canonical',
        'robots_index'        => '_seopress_robots_noindex',
        'robots_follow'       => '_seopress_robots_nofollow',
        'og_title'            => '_seopress_social_fb_title',
        'og_description'      => '_seopress_social_fb_desc',
        'twitter_title'       => '_seopress_social_twitter_title',
        'twitter_description' => '_seopress_social_twitter_desc',
    ];

    public function get_name(): string {
        return 'seopress';
    }

    public function get_label(): string {
        return 'SEOPress';
    }

    public function get_fields(): array {
        return [
            'title'               => 'SEOPress Title',
            'description'         => 'SEOPress Description',
            'focus_keyword'       => 'SEOPress Target Keyword',
            'canonical'           => 'SEOPress Canonical URL',
            'robots_index'        => 'SEOPress Robots Index (index/noindex)',
            'robots_follow'       => 'SEOPress Robots Follow (follow/nofollow)',
            'og_title'            => 'SEOPress Open Graph Title',
            'og_description'      => 'SEOPress Open Graph Description',
            'twitter_title'       => 'SEOPress Twitter Title',
            'twitter_description' => 'SEOPress Twitter Description',
        ];
    }

    public function get_meta(int $object_id, string $object_type, string $field_key): string {
        $meta_key = $this->field_map[$field_key] ?? '';
        if (empty($meta_key)) {
            return '';
        }

        $val = ($object_type === 'term') ? get_term_meta($object_id, $meta_key, true) : get_post_meta($object_id, $meta_key, true);

        if ($field_key === 'robots_index') {
            return $val === 'yes' ? 'noindex' : 'index';
        }
        if ($field_key === 'robots_follow') {
            return $val === 'yes' ? 'nofollow' : 'follow';
        }

        return (string) $val;
    }

    public function update_meta(int $object_id, string $object_type, string $field_key, $value): bool {
        $meta_key = $this->field_map[$field_key] ?? '';
        if (empty($meta_key)) {
            return false;
        }

        if ($field_key === 'robots_index') {
            $normalized = strtolower(trim((string)$value));
            $value = (strpos($normalized, 'no') !== false || $normalized === 'noindex') ? 'yes' : '';
        } elseif ($field_key === 'robots_follow') {
            $normalized = strtolower(trim((string)$value));
            $value = (strpos($normalized, 'no') !== false || $normalized === 'nofollow') ? 'yes' : '';
        }

        if ($object_type === 'term') {
            return update_term_meta($object_id, $meta_key, $value) !== false;
        } else {
            return update_post_meta($object_id, $meta_key, $value) !== false;
        }
    }
}
