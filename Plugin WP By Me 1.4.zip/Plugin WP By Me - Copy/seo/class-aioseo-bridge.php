<?php
namespace SEOMetaImporterPro\SEO;

defined('ABSPATH') || exit;

class Aioseo_Bridge extends SEO_Bridge {
    private array $field_map = [
        'title'               => '_aioseo_title',
        'description'         => '_aioseo_description',
        'focus_keyword'       => '_aioseo_keywords',
        'canonical'           => '_aioseo_canonical_url',
        'robots_index'        => '_aioseo_robots_noindex',
        'robots_follow'       => '_aioseo_robots_nofollow',
        'og_title'            => '_aioseo_og_title',
        'og_description'      => '_aioseo_og_description',
        'twitter_title'       => '_aioseo_twitter_title',
        'twitter_description' => '_aioseo_twitter_description',
    ];

    public function get_name(): string {
        return 'aioseo';
    }

    public function get_label(): string {
        return 'All in One SEO (AIOSEO)';
    }

    public function get_fields(): array {
        return [
            'title'               => 'AIOSEO Title',
            'description'         => 'AIOSEO Description',
            'focus_keyword'       => 'AIOSEO Keyphrase/Keywords',
            'canonical'           => 'AIOSEO Canonical URL',
            'robots_index'        => 'AIOSEO Robots Index (index/noindex)',
            'robots_follow'       => 'AIOSEO Robots Follow (follow/nofollow)',
            'og_title'            => 'AIOSEO Facebook Title',
            'og_description'      => 'AIOSEO Facebook Description',
            'twitter_title'       => 'AIOSEO Twitter Title',
            'twitter_description' => 'AIOSEO Twitter Description',
        ];
    }

    public function get_meta(int $object_id, string $object_type, string $field_key): string {
        $meta_key = $this->field_map[$field_key] ?? '';
        if (empty($meta_key)) {
            return '';
        }

        $val = ($object_type === 'term') ? get_term_meta($object_id, $meta_key, true) : get_post_meta($object_id, $meta_key, true);

        if ($field_key === 'robots_index') {
            if ($val == '1') return 'noindex';
            if ($val === '0' || $val === '0') return 'index';
            return 'default';
        }
        if ($field_key === 'robots_follow') {
            if ($val == '1') return 'nofollow';
            if ($val === '0' || $val === '0') return 'follow';
            return 'default';
        }

        return (string) $val;
    }

    public function update_meta(int $object_id, string $object_type, string $field_key, $value): bool {
        $meta_key = $this->field_map[$field_key] ?? '';
        if (empty($meta_key)) {
            return false;
        }

        if ($field_key === 'robots_index') {
            $normalized = strtolower(trim((string)$value));
            if (strpos($normalized, 'no') !== false || $normalized === 'noindex') {
                $value = '1';
            } elseif ($normalized === 'index') {
                $value = '0';
            } else {
                $value = '';
            }
        } elseif ($field_key === 'robots_follow') {
            $normalized = strtolower(trim((string)$value));
            if (strpos($normalized, 'no') !== false || $normalized === 'nofollow') {
                $value = '1';
            } elseif ($normalized === 'follow') {
                $value = '0';
            } else {
                $value = '';
            }
        }

        if ($object_type === 'term') {
            return update_term_meta($object_id, $meta_key, $value) !== false;
        } else {
            return update_post_meta($object_id, $meta_key, $value) !== false;
        }
    }
}
