<?php
namespace SEOMetaImporterPro\SEO;

defined('ABSPATH') || exit;

class Slimseo_Bridge extends SEO_Bridge {
    private array $key_map = [
        'title'               => 'title',
        'description'         => 'description',
        'canonical'           => 'canonical',
        'robots_index'        => 'noindex',
        'robots_follow'       => 'nofollow',
        'og_title'            => 'facebook_title',
        'og_description'      => 'facebook_description',
        'twitter_title'       => 'twitter_title',
        'twitter_description' => 'twitter_description',
    ];

    public function get_name(): string {
        return 'slimseo';
    }

    public function get_label(): string {
        return 'Slim SEO';
    }

    public function get_fields(): array {
        return [
            'title'               => 'Slim SEO Title',
            'description'         => 'Slim SEO Description',
            'canonical'           => 'Slim SEO Canonical URL',
            'robots_index'        => 'Slim SEO Robots Index (index/noindex)',
            'robots_follow'       => 'Slim SEO Robots Follow (follow/nofollow)',
            'og_title'            => 'Slim SEO Facebook Title',
            'og_description'      => 'Slim SEO Facebook Description',
            'twitter_title'       => 'Slim SEO Twitter Title',
            'twitter_description' => 'Slim SEO Twitter Description',
        ];
    }

    public function get_meta(int $object_id, string $object_type, string $field_key): string {
        $meta_key = 'slim_seo';
        $val_arr = ($object_type === 'term') ? get_term_meta($object_id, $meta_key, true) : get_post_meta($object_id, $meta_key, true);

        if (!is_array($val_arr)) {
            return '';
        }

        $array_key = $this->key_map[$field_key] ?? '';
        if (empty($array_key)) {
            return '';
        }

        $val = $val_arr[$array_key] ?? '';

        if ($field_key === 'robots_index') {
            return !empty($val) ? 'noindex' : 'index';
        }
        if ($field_key === 'robots_follow') {
            return !empty($val) ? 'nofollow' : 'follow';
        }

        return (string) $val;
    }

    public function update_meta(int $object_id, string $object_type, string $field_key, $value): bool {
        $meta_key = 'slim_seo';
        $val_arr = ($object_type === 'term') ? get_term_meta($object_id, $meta_key, true) : get_post_meta($object_id, $meta_key, true);

        if (!is_array($val_arr)) {
            $val_arr = [];
        }

        $array_key = $this->key_map[$field_key] ?? '';
        if (empty($array_key)) {
            return false;
        }

        if ($field_key === 'robots_index') {
            $normalized = strtolower(trim((string)$value));
            $value = (strpos($normalized, 'no') !== false || $normalized === 'noindex') ? 1 : 0;
        } elseif ($field_key === 'robots_follow') {
            $normalized = strtolower(trim((string)$value));
            $value = (strpos($normalized, 'no') !== false || $normalized === 'nofollow') ? 1 : 0;
        }

        if (empty($value) && $value !== 0 && $value !== '0') {
            unset($val_arr[$array_key]);
        } else {
            $val_arr[$array_key] = $value;
        }

        if ($object_type === 'term') {
            return update_term_meta($object_id, $meta_key, $val_arr) !== false;
        } else {
            return update_post_meta($object_id, $meta_key, $val_arr) !== false;
        }
    }
}
