<?php
namespace SEOMetaImporterPro\SEO;

defined('ABSPATH') || exit;

class Yoast_Bridge extends SEO_Bridge {
    private array $field_map = [
        'title'               => '_yoast_wpseo_title',
        'description'         => '_yoast_wpseo_metadesc',
        'focus_keyword'       => '_yoast_wpseo_focuskw',
        'canonical'           => '_yoast_wpseo_canonical',
        'robots_index'        => '_yoast_wpseo_meta-robots-noindex',
        'robots_follow'       => '_yoast_wpseo_meta-robots-nofollow',
        'og_title'            => '_yoast_wpseo_opengraph-title',
        'og_description'      => '_yoast_wpseo_opengraph-description',
        'twitter_title'       => '_yoast_wpseo_twitter-title',
        'twitter_description' => '_yoast_wpseo_twitter-description',
        'schema_type'         => '_yoast_wpseo_schema_page-type',
    ];

    public function get_name(): string {
        return 'yoast';
    }

    public function get_label(): string {
        return 'Yoast SEO';
    }

    public function get_fields(): array {
        return [
            'title'               => 'Yoast SEO Title',
            'description'         => 'Yoast SEO Meta Description',
            'focus_keyword'       => 'Yoast Focus Keyword',
            'canonical'           => 'Yoast Canonical URL',
            'robots_index'        => 'Yoast Robots Index (index/noindex)',
            'robots_follow'       => 'Yoast Robots Follow (follow/nofollow)',
            'og_title'            => 'Yoast Open Graph Title',
            'og_description'      => 'Yoast Open Graph Description',
            'twitter_title'       => 'Yoast Twitter Title',
            'twitter_description' => 'Yoast Twitter Description',
            'schema_type'         => 'Yoast Schema Page Type',
        ];
    }

    public function get_meta(int $object_id, string $object_type, string $field_key): string {
        $meta_key = $this->field_map[$field_key] ?? '';
        if (empty($meta_key)) {
            return '';
        }

        // For terms, Yoast sometimes strips leading underscores on older databases, check both
        if ($object_type === 'term') {
            $val = get_term_meta($object_id, $meta_key, true);
            if ($val === '') {
                $val = get_term_meta($object_id, ltrim($meta_key, '_'), true);
            }
        } else {
            $val = get_post_meta($object_id, $meta_key, true);
        }

        // Standardize output
        if ($field_key === 'robots_index') {
            if ($val == '1') return 'noindex';
            if ($val == '2') return 'index';
            return 'default';
        }
        if ($field_key === 'robots_follow') {
            if ($val == '1') return 'nofollow';
            if ($val == '2') return 'follow';
            return 'default';
        }

        return (string) $val;
    }

    public function update_meta(int $object_id, string $object_type, string $field_key, $value): bool {
        $meta_key = $this->field_map[$field_key] ?? '';
        if (empty($meta_key)) {
            return false;
        }

        // Process value conversions
        if ($field_key === 'robots_index') {
            $normalized = strtolower(trim((string)$value));
            if (strpos($normalized, 'no') !== false || $normalized === 'noindex') {
                $value = '1';
            } elseif ($normalized === 'index') {
                $value = '2';
            } else {
                $value = '0';
            }
        } elseif ($field_key === 'robots_follow') {
            $normalized = strtolower(trim((string)$value));
            if (strpos($normalized, 'no') !== false || $normalized === 'nofollow') {
                $value = '1';
            } elseif ($normalized === 'follow') {
                $value = '2';
            } else {
                $value = '0';
            }
        }

        if ($object_type === 'term') {
            // Update both standard and stripped keys to ensure maximum compatibility
            update_term_meta($object_id, $meta_key, $value);
            return update_term_meta($object_id, ltrim($meta_key, '_'), $value) !== false;
        } else {
            return update_post_meta($object_id, $meta_key, $value) !== false;
        }
    }
}
