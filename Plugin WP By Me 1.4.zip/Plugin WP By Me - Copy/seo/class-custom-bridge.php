<?php
namespace SEOMetaImporterPro\SEO;

defined('ABSPATH') || exit;

class Custom_Bridge extends SEO_Bridge {
    private array $field_map = [
        'title'               => '_seo_title',
        'description'         => '_seo_description',
        'focus_keyword'       => '_seo_focus_keyword',
        'canonical'           => '_seo_canonical',
        'robots_index'        => '_seo_robots_index',
        'robots_follow'       => '_seo_robots_follow',
        'og_title'            => '_seo_og_title',
        'og_description'      => '_seo_og_description',
        'twitter_title'       => '_seo_twitter_title',
        'twitter_description' => '_seo_twitter_description',
        'schema_type'         => '_seo_schema_type',
    ];

    public function get_name(): string {
        return 'custom';
    }

    public function get_label(): string {
        return 'Custom Post Meta (Fallback)';
    }

    public function get_fields(): array {
        return [
            'title'               => 'Custom Title Meta',
            'description'         => 'Custom Description Meta',
            'focus_keyword'       => 'Custom Focus Keyword Meta',
            'canonical'           => 'Custom Canonical Meta',
            'robots_index'        => 'Custom Robots Index Meta',
            'robots_follow'       => 'Custom Robots Follow Meta',
            'og_title'            => 'Custom Open Graph Title Meta',
            'og_description'      => 'Custom Open Graph Description Meta',
            'twitter_title'       => 'Custom Twitter Title Meta',
            'twitter_description' => 'Custom Twitter Description Meta',
            'schema_type'         => 'Custom Schema Type Meta',
        ];
    }

    public function get_meta(int $object_id, string $object_type, string $field_key): string {
        // If it starts with custom:, it's a direct meta key
        $meta_key = $field_key;
        if (strpos($field_key, 'custom:') === 0) {
            $meta_key = substr($field_key, 7);
        } else {
            $meta_key = $this->field_map[$field_key] ?? $field_key;
        }

        if (empty($meta_key)) {
            return '';
        }

        if ($object_type === 'term') {
            return (string) get_term_meta($object_id, $meta_key, true);
        } else {
            return (string) get_post_meta($object_id, $meta_key, true);
        }
    }

    public function update_meta(int $object_id, string $object_type, string $field_key, $value): bool {
        $meta_key = $field_key;
        if (strpos($field_key, 'custom:') === 0) {
            $meta_key = substr($field_key, 7);
        } else {
            $meta_key = $this->field_map[$field_key] ?? $field_key;
        }

        if (empty($meta_key)) {
            return false;
        }

        if ($object_type === 'term') {
            return update_term_meta($object_id, $meta_key, $value) !== false;
        } else {
            return update_post_meta($object_id, $meta_key, $value) !== false;
        }
    }
}
