<?php
namespace SEOMetaImporterPro\SEO;

defined('ABSPATH') || exit;

class Rankmath_Bridge extends SEO_Bridge {
    private array $field_map = [
        'title'               => 'rank_math_title',
        'description'         => 'rank_math_description',
        'focus_keyword'       => 'rank_math_focus_keyword',
        'canonical'           => 'rank_math_canonical',
        'robots_index'        => 'rank_math_robots',
        'robots_follow'       => 'rank_math_robots',
        'og_title'            => 'rank_math_facebook_title',
        'og_description'      => 'rank_math_facebook_description',
        'twitter_title'       => 'rank_math_twitter_title',
        'twitter_description' => 'rank_math_twitter_description',
        'schema_type'         => 'rank_math_rich_snippet',
    ];

    public function get_name(): string {
        return 'rankmath';
    }

    public function get_label(): string {
        return 'Rank Math SEO';
    }

    public function get_fields(): array {
        return [
            'title'               => 'Rank Math Title',
            'description'         => 'Rank Math Description',
            'focus_keyword'       => 'Rank Math Focus Keyword',
            'canonical'           => 'Rank Math Canonical URL',
            'robots_index'        => 'Rank Math Robots Index (index/noindex)',
            'robots_follow'       => 'Rank Math Robots Follow (follow/nofollow)',
            'og_title'            => 'Rank Math Facebook Title',
            'og_description'      => 'Rank Math Facebook Description',
            'twitter_title'       => 'Rank Math Twitter Title',
            'twitter_description' => 'Rank Math Twitter Description',
            'schema_type'         => 'Rank Math Schema/Snippet Type',
        ];
    }

    public function get_meta(int $object_id, string $object_type, string $field_key): string {
        $meta_key = $this->field_map[$field_key] ?? '';
        if (empty($meta_key)) {
            return '';
        }

        $val = ($object_type === 'term') ? get_term_meta($object_id, $meta_key, true) : get_post_meta($object_id, $meta_key, true);

        if ($field_key === 'robots_index' || $field_key === 'robots_follow') {
            if (!is_array($val)) {
                return 'default';
            }
            if ($field_key === 'robots_index') {
                return in_array('noindex', $val, true) ? 'noindex' : (in_array('index', $val, true) ? 'index' : 'default');
            } else {
                return in_array('nofollow', $val, true) ? 'nofollow' : (in_array('follow', $val, true) ? 'follow' : 'default');
            }
        }

        return (string) $val;
    }

    public function update_meta(int $object_id, string $object_type, string $field_key, $value): bool {
        $meta_key = $this->field_map[$field_key] ?? '';
        if (empty($meta_key)) {
            return false;
        }

        if ($field_key === 'robots_index' || $field_key === 'robots_follow') {
            $existing = ($object_type === 'term') ? get_term_meta($object_id, $meta_key, true) : get_post_meta($object_id, $meta_key, true);
            if (!is_array($existing)) {
                $existing = [];
            }

            $normalized = strtolower(trim((string)$value));

            if ($field_key === 'robots_index') {
                // Remove existing index/noindex settings
                $existing = array_diff($existing, ['index', 'noindex']);
                if (strpos($normalized, 'no') !== false || $normalized === 'noindex') {
                    $existing[] = 'noindex';
                } elseif ($normalized === 'index') {
                    $existing[] = 'index';
                }
            } else {
                // Remove existing follow/nofollow settings
                $existing = array_diff($existing, ['follow', 'nofollow']);
                if (strpos($normalized, 'no') !== false || $normalized === 'nofollow') {
                    $existing[] = 'nofollow';
                } elseif ($normalized === 'follow') {
                    $existing[] = 'follow';
                }
            }

            $value = $existing;
        }

        if ($object_type === 'term') {
            return update_term_meta($object_id, $meta_key, $value) !== false;
        } else {
            return update_post_meta($object_id, $meta_key, $value) !== false;
        }
    }
}
