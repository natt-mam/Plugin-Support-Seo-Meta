<?php
namespace SEOMetaImporterPro\CLI;

defined('ABSPATH') || exit;

if (!defined('WP_CLI') || !WP_CLI) {
    return;
}

class Cli_Commands {
    /**
     * Register WP-CLI commands.
     */
    public static function register(): void {
        \WP_CLI::add_command('seo-import', [self::class, 'seo_import']);
        \WP_CLI::add_command('seo-export', [self::class, 'seo_export']);
        \WP_CLI::add_command('seo-sync-google', [self::class, 'seo_sync_google']);
    }

    /**
     * Bulk import SEO metadata from a CSV file.
     * 
     * ## OPTIONS
     * 
     * <file>
     * : Path to the CSV file to import.
     * 
     * [--mapping=<mapping_json>]
     * : JSON string of mapping configurations (e.g. '{"URL":"_identifier","Title":"title"}'). If omitted, mapping is auto-detected.
     * 
     * [--seo_plugin=<plugin>]
     * : Which SEO plugin to update. Options: yoast, rankmath, aioseo, seopress, slimseo, tsf, custom. Default: auto.
     * 
     * [--dry_run]
     * : Run import validation and simulation without saving database changes.
     * 
     * ## EXAMPLES
     * 
     *     wp seo-import data.csv --seo_plugin=yoast
     *     wp seo-import data.csv --mapping='{"URL":"_identifier","Title":"title"}' --dry_run
     */
    public static function seo_import(array $args, array $assoc_args): void {
        $file = $args[0];
        if (!file_exists($file)) {
            \WP_CLI::error(sprintf(__('CSV file not found: %s', 'seo-meta-importer-pro'), $file));
        }

        // Delimiter and Encoding defaults
        $delimiter = ',';
        $encoding = 'UTF-8';

        $headers = \SEOMetaImporterPro\Import\Csv_Parser::get_headers($file, $delimiter, $encoding);
        if (empty($headers)) {
            \WP_CLI::error(__('Unable to read headers from CSV file.', 'seo-meta-importer-pro'));
        }

        // Handle Mapping
        $mapping = [];
        if (!empty($assoc_args['mapping'])) {
            $mapping = json_decode($assoc_args['mapping'], true);
            if (!is_array($mapping)) {
                \WP_CLI::error(__('Invalid JSON format for mapping parameter.', 'seo-meta-importer-pro'));
            }
        } else {
            // Auto map
            \WP_CLI::line(__('No mapping specified. Attempting auto-detection...', 'seo-meta-importer-pro'));
            $field_keys = [
                '_identifier'         => ['url', 'permalink', 'link', 'page url', 'product url', 'id', 'slug'],
                'title'               => ['title', 'seo title', 'meta title'],
                'description'         => ['description', 'meta description', 'meta desc'],
                'focus_keyword'       => ['keyword', 'keywords', 'focus keyword', 'keyphrase'],
                'canonical'           => ['canonical', 'canonical url'],
                'robots_index'        => ['robots index', 'noindex', 'index'],
                'robots_follow'       => ['robots follow', 'nofollow', 'follow'],
                'og_title'            => ['og title', 'facebook title', 'open graph title'],
                'og_description'      => ['og description', 'facebook description', 'open graph description'],
                'twitter_title'       => ['twitter title'],
                'twitter_description' => ['twitter description'],
            ];

            foreach ($headers as $header) {
                $cleaned = strtolower(trim($header));
                foreach ($field_keys as $key => $synonyms) {
                    if (in_array($cleaned, $synonyms, true)) {
                        $mapping[$header] = $key;
                        break;
                    }
                }
            }
        }

        // Verify we have Page Identifier mapped
        if (!in_array('_identifier', $mapping, true)) {
            \WP_CLI::error(__('Mapping must contain a Page Identifier column mapped to "_identifier".', 'seo-meta-importer-pro'));
        }

        $dry_run = isset($assoc_args['dry_run']);
        $seo_plugin = $assoc_args['seo_plugin'] ?? 'auto';

        $settings = [
            'identifier_type' => 'auto',
            'seo_plugin'      => $seo_plugin,
            'dry_run'         => $dry_run,
            'filters'         => [], // no filters by default in CLI unless requested
        ];

        $total_rows = \SEOMetaImporterPro\Import\Csv_Parser::get_total_rows($file);
        \WP_CLI::line(sprintf(__('Found %d rows to import.', 'seo-meta-importer-pro'), $total_rows));

        // Insert database run
        $import_id = \SEOMetaImporterPro\Includes\Database::insert_history([
            'filename'    => basename($file),
            'seo_plugin'  => $seo_plugin,
            'status'      => 'running',
            'import_type' => 'cli_command',
        ]);

        $engine = new \SEOMetaImporterPro\Import\Import_Engine($file, $mapping, $settings);
        $engine->set_import_id($import_id);

        $progress = \WP_CLI\Utils\make_progress_bar(__('Importing metadata', 'seo-meta-importer-pro'), $total_rows);

        $offset = 0;
        $batch = 200;
        $updated = 0;
        $failed = 0;

        $start_time = microtime(true);

        while ($offset < $total_rows) {
            $result = $engine->process_batch($offset, $batch);
            if (is_wp_error($result)) {
                \WP_CLI::error($result->get_error_message());
            }

            $updated += $result['updated'];
            $failed += $result['failed'];
            
            $progress->tick(min($batch, $total_rows - $offset));
            $offset += $batch;
        }

        $progress->finish();

        $end_time = microtime(true);
        $execution_time = $end_time - $start_time;

        \SEOMetaImporterPro\Includes\Database::update_history($import_id, [
            'rows_updated'   => $updated,
            'rows_failed'    => $failed,
            'execution_time' => $execution_time,
            'status'         => 'completed',
        ]);

        if ($dry_run) {
            \WP_CLI::success(sprintf(__('Dry run completed. Processed %d matches, %d skipped/failures.', 'seo-meta-importer-pro'), $updated, $failed));
        } else {
            \WP_CLI::success(sprintf(__('Import completed successfully. %d rows updated, %d rows failed in %.2f seconds.', 'seo-meta-importer-pro'), $updated, $failed, $execution_time));
        }
    }

    /**
     * Export SEO metadata to CSV.
     * 
     * ## OPTIONS
     * 
     * [--post_types=<post_types>]
     * : Comma-separated list of post types. Default: post,page.
     * 
     * [--taxonomies=<taxonomies>]
     * : Comma-separated list of taxonomies. Default: category,post_tag.
     * 
     * [--seo_plugin=<plugin>]
     * : SEO plugin to pull data from. Default: auto.
     * 
     * [--output=<output_file>]
     * : Custom path to write the CSV file. If omitted, prints file path.
     * 
     * ## EXAMPLES
     * 
     *     wp seo-export --post_types=product --output=products-seo.csv
     */
    public static function seo_export(array $args, array $assoc_args): void {
        $post_types_str = $assoc_args['post_types'] ?? 'post,page';
        $taxonomies_str = $assoc_args['taxonomies'] ?? 'category,post_tag';
        $seo_plugin = $assoc_args['seo_plugin'] ?? 'auto';

        $filters = [
            'post_types' => explode(',', $post_types_str),
            'taxonomies' => explode(',', $taxonomies_str),
        ];

        \WP_CLI::line(__('Compiling SEO Metadata export...', 'seo-meta-importer-pro'));

        $result = \SEOMetaImporterPro\Export\Export_Engine::generate_export($filters, $seo_plugin);
        if (is_wp_error($result)) {
            \WP_CLI::error($result->get_error_message());
        }

        if (isset($assoc_args['output'])) {
            $dest = $assoc_args['output'];
            if (copy($result, $dest)) {
                unlink($result);
                \WP_CLI::success(sprintf(__('Export written to file: %s', 'seo-meta-importer-pro'), $dest));
            } else {
                \WP_CLI::error(sprintf(__('Failed to copy temporary file to destination: %s', 'seo-meta-importer-pro'), $dest));
            }
        } else {
            \WP_CLI::success(sprintf(__('Export compiled successfully. Temporary file path: %s', 'seo-meta-importer-pro'), $result));
        }
    }

    /**
     * Trigger Google Sheets synchronization and import.
     * 
     * ## EXAMPLES
     * 
     *     wp seo-sync-google
     */
    public static function seo_sync_google(array $args, array $assoc_args): void {
        \WP_CLI::line(__('Retrieving Google Sheet URL configuration...', 'seo-meta-importer-pro'));
        
        $url = get_option('smip_google_sheet_url', '');
        if (empty($url)) {
            \WP_CLI::error(__('Google Sheet URL is not configured in settings.', 'seo-meta-importer-pro'));
        }

        \WP_CLI::line(sprintf(__('Downloading spreadsheet: %s', 'seo-meta-importer-pro'), $url));
        $api_key = get_option('smip_google_sheets_api_key', '');
        
        $file = \SEOMetaImporterPro\Google\Sheets_Client::download_sheet_to_file($url, $api_key);
        if (is_wp_error($file)) {
            \WP_CLI::error($file->get_error_message());
        }

        // Trigger CLI import process directly
        // We reuse import logic, but we'll mock the assoc args
        self::seo_import([$file], [
            'seo_plugin' => get_option('smip_default_seo_plugin', 'auto'),
        ]);

        unlink($file); // clean up
    }
}
